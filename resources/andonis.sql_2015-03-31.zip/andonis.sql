-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 31, 2015 at 09:07 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `andonis`
--

-- --------------------------------------------------------

--
-- Table structure for table `ethnicity`
--

DROP TABLE IF EXISTS `ethnicity`;
CREATE TABLE IF NOT EXISTS `ethnicity` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `main_id` int(10) NOT NULL DEFAULT '0',
  `child_id` int(10) NOT NULL DEFAULT '0',
  `name` varchar(250) NOT NULL DEFAULT '',
  `sort_order` int(4) NOT NULL DEFAULT '0',
  `example` varchar(250) NOT NULL DEFAULT '',
  `tt_width_cls` varchar(25) NOT NULL DEFAULT '',
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `ethnicity`
--

INSERT INTO `ethnicity` (`id`, `main_id`, `child_id`, `name`, `sort_order`, `example`, `tt_width_cls`, `status`) VALUES
(1, 0, 0, 'European', 1, '', '', 1),
(2, 0, 0, 'Native American', 4, '', '', 1),
(3, 0, 0, 'Middle Eastern', 8, 'e.g. Saudi Arabia, Syria, Iraq', '', 1),
(4, 0, 0, 'Arab', 7, '', '', 1),
(5, 0, 0, 'African', 3, '', '', 1),
(6, 0, 0, 'Asian', 6, '', '', 1),
(7, 0, 0, 'Latin', 2, '', '', 1),
(8, 0, 0, 'Pacific islander', 5, '', '', 1),
(9, 1, 0, 'NW European', 0, 'e.g. UK, Ireland, Germany, N.France, Norway', '', 1),
(10, 1, 0, 'NE European', 0, 'e.g. Russia, Ukraine, Poland, Lithuania', '', 1),
(11, 1, 0, 'South European', 0, 'e.g. Spain, S. France, Italy, Greece', '', 1),
(12, 1, 0, 'Russian', 0, '', '', 0),
(13, 1, 0, 'North American', 0, 'e.g.  U.S.A, Canada', '', 0),
(14, 1, 0, 'South American', 0, 'e.g.  Argentina, Brazil', '', 0),
(15, 1, 0, 'Australian/New Zealander', 0, '', '', 0),
(16, 1, 0, 'South African', 0, '', '', 0),
(17, 1, 0, 'Other', 0, '', '', 0),
(18, 3, 0, 'Turkish', 0, '', '', 0),
(19, 3, 0, 'Jewish/Hebrew', 0, '', '', 0),
(20, 3, 0, 'Iranian', 0, '', '', 0),
(21, 3, 0, 'Other', 0, '', '', 0),
(22, 4, 0, 'North African', 0, 'e.g. Morocco, Libya, Egypt', '', 1),
(23, 4, 0, 'Middle Eastern', 0, 'e.g.  Saudi Arabia, Syria, Iraq', '', 1),
(24, 4, 0, 'Other', 0, '', '', 1),
(25, 5, 0, 'African', 0, 'e.g.  Nigeria, Kenya, Sudan', '', 0),
(26, 5, 0, 'European', 0, 'e.g.  UK, Italy, France', '', 0),
(27, 5, 0, 'American', 0, 'e.g.  USA, Canada', '', 0),
(28, 5, 0, 'Caribbean', 0, 'e.g. Jamaica, Haiti, Dominican Republic', 'with250', 0),
(29, 5, 0, 'Asian', 0, 'e.g.  China, India, Japan', '', 0),
(30, 5, 0, 'Australian/New Zealander', 0, '', '', 0),
(31, 5, 0, 'Other', 0, '', '', 0),
(32, 6, 0, 'NE Asian', 0, '', '', 1),
(33, 6, 0, 'SW Asian', 0, 'e.g. India, Pakistan, Bangladesh', '', 1),
(34, 6, 0, 'SE Asian', 0, 'e.g. Indonesian, Thai, Filipino', '', 1),
(35, 6, 32, 'Chinese', 0, '', '', 1),
(36, 6, 32, 'Japanese', 0, '', '', 1),
(37, 6, 32, 'Korean', 0, 'e.g.  Kazakhstan, Afghanistan', '', 1),
(39, 6, 0, 'Other', 0, '', '', 0),
(40, 7, 0, 'Mexican', 0, '', '', 1),
(41, 7, 0, 'Central American', 0, 'e.g. Guatemala, Nicaragua, Panama', '', 1),
(42, 7, 0, 'South American', 0, 'e.g. Colombia, Venezuela, Brazil', '', 1),
(43, 7, 0, 'Caribbean', 0, 'e.g. Cuba, Puerto Rico', '', 1),
(44, 7, 0, 'Other', 0, '', '', 0),
(45, 3, 0, 'Turkish', 0, '', '', 1),
(46, 3, 0, 'Jewish', 0, '', '', 1),
(47, 3, 0, 'Iranian', 0, '', '', 1),
(48, 3, 0, 'Other', 0, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

DROP TABLE IF EXISTS `level`;
CREATE TABLE IF NOT EXISTS `level` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `level` int(4) NOT NULL DEFAULT '0',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT 'type 1 => past | 2 => present',
  `label` varchar(100) NOT NULL DEFAULT '',
  `heading` varchar(25) NOT NULL DEFAULT '',
  `questions` int(4) NOT NULL DEFAULT '0',
  `total_sub_question` int(4) NOT NULL DEFAULT '0',
  `step_progress` double(6,2) NOT NULL DEFAULT '0.00',
  `progress` double(6,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`id`, `level`, `type`, `label`, `heading`, `questions`, `total_sub_question`, `step_progress`, `progress`) VALUES
(1, 1, 1, 'past_level_1', 'Level 1', 62, 172, 0.58, 0.00),
(2, 2, 1, 'past_level_2', 'Level 2', 65, 130, 0.77, 0.00),
(3, 3, 1, 'past_level_3', 'Level 3', 65, 130, 0.77, 0.00),
(4, 4, 1, 'past_level_4', 'Level 4', 63, 104, 0.97, 0.00),
(5, 5, 1, 'past_level_5', 'Level 5', 60, 76, 1.32, 0.00),
(6, 6, 1, 'past_level_6', 'Level 6', 52, 100, 1.00, 0.00),
(7, 7, 1, 'past_level_7', 'Outcome', 1, 1, 0.00, 0.00),
(8, 1, 2, 'present_level_1', 'Level 1', 62, 172, 0.58, 0.00),
(9, 2, 2, 'present_level_2', 'Level 2', 65, 130, 0.77, 0.00),
(10, 3, 2, 'present_level_3', 'Level 3', 65, 130, 0.77, 0.00),
(11, 4, 2, 'present_level_4', 'Level 4', 63, 104, 0.97, 0.00),
(12, 5, 2, 'present_level_5', 'Level 5', 60, 76, 1.32, 0.00),
(13, 6, 2, 'present_level_6', 'Level 6', 52, 100, 1.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_3`
--

DROP TABLE IF EXISTS `qa_1_3`;
CREATE TABLE IF NOT EXISTS `qa_1_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_3`
--

INSERT INTO `qa_1_3` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`, `q_3`, `q_3_pl`, `q_3_status`, `q_4`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '0,0,0,0', 3, 0, '0,0,0,0', 3, 0, '0,0,0,0', 3, 0, '0,0,0,0', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_4`
--

DROP TABLE IF EXISTS `qa_1_4`;
CREATE TABLE IF NOT EXISTS `qa_1_4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_4`
--

INSERT INTO `qa_1_4` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`, `q_3`, `q_3_pl`, `q_3_status`, `q_4`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_5`
--

DROP TABLE IF EXISTS `qa_1_5`;
CREATE TABLE IF NOT EXISTS `qa_1_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_5`
--

INSERT INTO `qa_1_5` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`, `q_3`, `q_3_pl`, `q_3_status`, `q_4`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '0,0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0,0', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_6`
--

DROP TABLE IF EXISTS `qa_1_6`;
CREATE TABLE IF NOT EXISTS `qa_1_6` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_6`
--

INSERT INTO `qa_1_6` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`, `q_3`, `q_3_pl`, `q_3_status`, `q_4`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_7`
--

DROP TABLE IF EXISTS `qa_1_7`;
CREATE TABLE IF NOT EXISTS `qa_1_7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_7`
--

INSERT INTO `qa_1_7` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`, `q_3`, `q_3_pl`, `q_3_status`, `q_4`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_8`
--

DROP TABLE IF EXISTS `qa_1_8`;
CREATE TABLE IF NOT EXISTS `qa_1_8` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_min` int(10) NOT NULL DEFAULT '0',
  `q_1_max` int(10) NOT NULL DEFAULT '0',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_min` int(10) NOT NULL DEFAULT '0',
  `q_2_max` int(10) NOT NULL DEFAULT '0',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_min` int(10) NOT NULL DEFAULT '0',
  `q_3_max` int(10) NOT NULL DEFAULT '0',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_min` int(10) NOT NULL DEFAULT '0',
  `q_4_max` int(10) NOT NULL DEFAULT '0',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_8`
--

INSERT INTO `qa_1_8` (`id`, `user_id`, `type`, `q_1_min`, `q_1_max`, `q_1_pl`, `q_1_status`, `q_2_min`, `q_2_max`, `q_2_pl`, `q_2_status`, `q_3_min`, `q_3_max`, `q_3_pl`, `q_3_status`, `q_4_min`, `q_4_max`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, 50, 200, 3, 1, 50, 200, 3, 1, 50, 200, 3, 1, 50, 200, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_9`
--

DROP TABLE IF EXISTS `qa_1_9`;
CREATE TABLE IF NOT EXISTS `qa_1_9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_min` int(10) NOT NULL DEFAULT '0',
  `q_1_max` int(10) NOT NULL DEFAULT '0',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_min` int(10) NOT NULL DEFAULT '0',
  `q_2_max` int(10) NOT NULL DEFAULT '0',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_yn` varchar(1) NOT NULL DEFAULT '',
  `q_3_min` int(10) NOT NULL DEFAULT '0',
  `q_3_max` int(10) NOT NULL DEFAULT '0',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_yn` varchar(1) NOT NULL DEFAULT '',
  `q_4_min` int(10) NOT NULL DEFAULT '0',
  `q_4_max` int(10) NOT NULL DEFAULT '0',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_9`
--

INSERT INTO `qa_1_9` (`id`, `user_id`, `type`, `q_1_yn`, `q_1_min`, `q_1_max`, `q_1_pl`, `q_1_status`, `q_2_yn`, `q_2_min`, `q_2_max`, `q_2_pl`, `q_2_status`, `q_3_yn`, `q_3_min`, `q_3_max`, `q_3_pl`, `q_3_status`, `q_4_yn`, `q_4_min`, `q_4_max`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '-', 0, 0, 3, 0, '-', 0, 0, 3, 0, '-', 0, 0, 3, 0, '-', 0, 0, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_10`
--

DROP TABLE IF EXISTS `qa_1_10`;
CREATE TABLE IF NOT EXISTS `qa_1_10` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_min` int(10) NOT NULL DEFAULT '0',
  `q_1_max` int(10) NOT NULL DEFAULT '0',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_min` int(10) NOT NULL DEFAULT '0',
  `q_2_max` int(10) NOT NULL DEFAULT '0',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_yn` varchar(1) NOT NULL DEFAULT '',
  `q_3_min` int(10) NOT NULL DEFAULT '0',
  `q_3_max` int(10) NOT NULL DEFAULT '0',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_yn` varchar(1) NOT NULL DEFAULT '',
  `q_4_min` int(10) NOT NULL DEFAULT '0',
  `q_4_max` int(10) NOT NULL DEFAULT '0',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_10`
--

INSERT INTO `qa_1_10` (`id`, `user_id`, `type`, `q_1_yn`, `q_1_min`, `q_1_max`, `q_1_pl`, `q_1_status`, `q_2_yn`, `q_2_min`, `q_2_max`, `q_2_pl`, `q_2_status`, `q_3_yn`, `q_3_min`, `q_3_max`, `q_3_pl`, `q_3_status`, `q_4_yn`, `q_4_min`, `q_4_max`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '-', 0, 0, 3, 0, '-', 0, 0, 3, 0, '-', 0, 0, 3, 0, '-', 0, 0, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_11`
--

DROP TABLE IF EXISTS `qa_1_11`;
CREATE TABLE IF NOT EXISTS `qa_1_11` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_yn` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_yn` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_11`
--

INSERT INTO `qa_1_11` (`id`, `user_id`, `type`, `q_1_yn`, `q_1_pl`, `q_1_status`, `q_2_yn`, `q_2_pl`, `q_2_status`, `q_3_yn`, `q_3_pl`, `q_3_status`, `q_4_yn`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '-', 3, 0, '-', 3, 0, '-', 3, 0, '-', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_12`
--

DROP TABLE IF EXISTS `qa_1_12`;
CREATE TABLE IF NOT EXISTS `qa_1_12` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_12`
--

INSERT INTO `qa_1_12` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`, `q_3`, `q_3_pl`, `q_3_status`, `q_4`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0, '0,0,0,0,0,0,0', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_13`
--

DROP TABLE IF EXISTS `qa_1_13`;
CREATE TABLE IF NOT EXISTS `qa_1_13` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_13`
--

INSERT INTO `qa_1_13` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '0,0,0,0,0', 3, 0, '0,0,0,0,0', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_14`
--

DROP TABLE IF EXISTS `qa_1_14`;
CREATE TABLE IF NOT EXISTS `qa_1_14` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_14`
--

INSERT INTO `qa_1_14` (`id`, `user_id`, `type`, `q_1_v_1`, `q_1_v_2`, `q_1_pl`, `q_1_status`, `q_2_v_1`, `q_2_v_2`, `q_2_pl`, `q_2_status`, `q_3_v_1`, `q_3_v_2`, `q_3_pl`, `q_3_status`, `q_4_v_1`, `q_4_v_2`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '-', '-', 3, 0, '-', '-', 3, 0, '-', '-', 3, 0, '-', '-', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_15`
--

DROP TABLE IF EXISTS `qa_1_15`;
CREATE TABLE IF NOT EXISTS `qa_1_15` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_15`
--

INSERT INTO `qa_1_15` (`id`, `user_id`, `type`, `q_1_1_yn`, `q_1_pl`, `q_1_status`, `q_2_1_yn`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '-', 3, 0, '-', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_16`
--

DROP TABLE IF EXISTS `qa_1_16`;
CREATE TABLE IF NOT EXISTS `qa_1_16` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_16`
--

INSERT INTO `qa_1_16` (`id`, `user_id`, `type`, `q_1_1_yn`, `q_1_pl`, `q_1_status`, `q_2_1_yn`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '-', 3, 0, '-', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_17`
--

DROP TABLE IF EXISTS `qa_1_17`;
CREATE TABLE IF NOT EXISTS `qa_1_17` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_1_17`
--

INSERT INTO `qa_1_17` (`id`, `user_id`, `type`, `q_1_v_1`, `q_1_v_2`, `q_1_pl`, `q_1_status`, `q_2_v_1`, `q_2_v_2`, `q_2_pl`, `q_2_status`, `q_3_v_1`, `q_3_v_2`, `q_3_pl`, `q_3_status`, `q_4_v_1`, `q_4_v_2`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '-', '-', 3, 0, '-', '-', 3, 0, '-', '-', 3, 0, '-', '-', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_1_18`
--

DROP TABLE IF EXISTS `qa_1_18`;
CREATE TABLE IF NOT EXISTS `qa_1_18` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_18`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_19`
--

DROP TABLE IF EXISTS `qa_1_19`;
CREATE TABLE IF NOT EXISTS `qa_1_19` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_19`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_20`
--

DROP TABLE IF EXISTS `qa_1_20`;
CREATE TABLE IF NOT EXISTS `qa_1_20` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_20`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_21`
--

DROP TABLE IF EXISTS `qa_1_21`;
CREATE TABLE IF NOT EXISTS `qa_1_21` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_21`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_22`
--

DROP TABLE IF EXISTS `qa_1_22`;
CREATE TABLE IF NOT EXISTS `qa_1_22` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v` varchar(5) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v` varchar(5) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v` varchar(5) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v` varchar(5) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_22`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_23`
--

DROP TABLE IF EXISTS `qa_1_23`;
CREATE TABLE IF NOT EXISTS `qa_1_23` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_23`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_24`
--

DROP TABLE IF EXISTS `qa_1_24`;
CREATE TABLE IF NOT EXISTS `qa_1_24` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v` smallint(6) NOT NULL,
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v` smallint(6) NOT NULL,
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_24`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_25`
--

DROP TABLE IF EXISTS `qa_1_25`;
CREATE TABLE IF NOT EXISTS `qa_1_25` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_25`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_26`
--

DROP TABLE IF EXISTS `qa_1_26`;
CREATE TABLE IF NOT EXISTS `qa_1_26` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_26`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_27`
--

DROP TABLE IF EXISTS `qa_1_27`;
CREATE TABLE IF NOT EXISTS `qa_1_27` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_27`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_28`
--

DROP TABLE IF EXISTS `qa_1_28`;
CREATE TABLE IF NOT EXISTS `qa_1_28` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_28`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_29`
--

DROP TABLE IF EXISTS `qa_1_29`;
CREATE TABLE IF NOT EXISTS `qa_1_29` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_29`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_30`
--

DROP TABLE IF EXISTS `qa_1_30`;
CREATE TABLE IF NOT EXISTS `qa_1_30` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_30`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_31`
--

DROP TABLE IF EXISTS `qa_1_31`;
CREATE TABLE IF NOT EXISTS `qa_1_31` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_3_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_4_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_31`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_32`
--

DROP TABLE IF EXISTS `qa_1_32`;
CREATE TABLE IF NOT EXISTS `qa_1_32` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_1_yn` varchar(1) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_1_yn` varchar(1) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_1_yn` varchar(1) NOT NULL,
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_1_yn` varchar(1) NOT NULL,
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_32`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_33`
--

DROP TABLE IF EXISTS `qa_1_33`;
CREATE TABLE IF NOT EXISTS `qa_1_33` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_1_yn` varchar(1) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_1_yn` varchar(1) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3_1_yn` varchar(1) NOT NULL,
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4_1_yn` varchar(1) NOT NULL,
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_33`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_34`
--

DROP TABLE IF EXISTS `qa_1_34`;
CREATE TABLE IF NOT EXISTS `qa_1_34` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_34`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_35`
--

DROP TABLE IF EXISTS `qa_1_35`;
CREATE TABLE IF NOT EXISTS `qa_1_35` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_35`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_36`
--

DROP TABLE IF EXISTS `qa_1_36`;
CREATE TABLE IF NOT EXISTS `qa_1_36` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_36`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_37`
--

DROP TABLE IF EXISTS `qa_1_37`;
CREATE TABLE IF NOT EXISTS `qa_1_37` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_37`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_38`
--

DROP TABLE IF EXISTS `qa_1_38`;
CREATE TABLE IF NOT EXISTS `qa_1_38` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_v_1` varchar(5) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(5) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_38`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_39`
--

DROP TABLE IF EXISTS `qa_1_39`;
CREATE TABLE IF NOT EXISTS `qa_1_39` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_39`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_40`
--

DROP TABLE IF EXISTS `qa_1_40`;
CREATE TABLE IF NOT EXISTS `qa_1_40` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(50) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_40`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_41`
--

DROP TABLE IF EXISTS `qa_1_41`;
CREATE TABLE IF NOT EXISTS `qa_1_41` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_41`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_42`
--

DROP TABLE IF EXISTS `qa_1_42`;
CREATE TABLE IF NOT EXISTS `qa_1_42` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_42`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_43`
--

DROP TABLE IF EXISTS `qa_1_43`;
CREATE TABLE IF NOT EXISTS `qa_1_43` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_43`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_44`
--

DROP TABLE IF EXISTS `qa_1_44`;
CREATE TABLE IF NOT EXISTS `qa_1_44` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_44`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_45`
--

DROP TABLE IF EXISTS `qa_1_45`;
CREATE TABLE IF NOT EXISTS `qa_1_45` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_45`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_46`
--

DROP TABLE IF EXISTS `qa_1_46`;
CREATE TABLE IF NOT EXISTS `qa_1_46` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_46`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_47`
--

DROP TABLE IF EXISTS `qa_1_47`;
CREATE TABLE IF NOT EXISTS `qa_1_47` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_47`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_48`
--

DROP TABLE IF EXISTS `qa_1_48`;
CREATE TABLE IF NOT EXISTS `qa_1_48` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_48`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_49`
--

DROP TABLE IF EXISTS `qa_1_49`;
CREATE TABLE IF NOT EXISTS `qa_1_49` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_49`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_50`
--

DROP TABLE IF EXISTS `qa_1_50`;
CREATE TABLE IF NOT EXISTS `qa_1_50` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_50`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_51`
--

DROP TABLE IF EXISTS `qa_1_51`;
CREATE TABLE IF NOT EXISTS `qa_1_51` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_51`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_52`
--

DROP TABLE IF EXISTS `qa_1_52`;
CREATE TABLE IF NOT EXISTS `qa_1_52` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_52`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_53`
--

DROP TABLE IF EXISTS `qa_1_53`;
CREATE TABLE IF NOT EXISTS `qa_1_53` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_53`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_54`
--

DROP TABLE IF EXISTS `qa_1_54`;
CREATE TABLE IF NOT EXISTS `qa_1_54` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_54`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_55`
--

DROP TABLE IF EXISTS `qa_1_55`;
CREATE TABLE IF NOT EXISTS `qa_1_55` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_55`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_56`
--

DROP TABLE IF EXISTS `qa_1_56`;
CREATE TABLE IF NOT EXISTS `qa_1_56` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_56`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_57`
--

DROP TABLE IF EXISTS `qa_1_57`;
CREATE TABLE IF NOT EXISTS `qa_1_57` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_57`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_58`
--

DROP TABLE IF EXISTS `qa_1_58`;
CREATE TABLE IF NOT EXISTS `qa_1_58` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_58`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_59`
--

DROP TABLE IF EXISTS `qa_1_59`;
CREATE TABLE IF NOT EXISTS `qa_1_59` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_59`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_60`
--

DROP TABLE IF EXISTS `qa_1_60`;
CREATE TABLE IF NOT EXISTS `qa_1_60` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_60`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_61`
--

DROP TABLE IF EXISTS `qa_1_61`;
CREATE TABLE IF NOT EXISTS `qa_1_61` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_61`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_1_62`
--

DROP TABLE IF EXISTS `qa_1_62`;
CREATE TABLE IF NOT EXISTS `qa_1_62` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_1_62`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_1`
--

DROP TABLE IF EXISTS `qa_2_1`;
CREATE TABLE IF NOT EXISTS `qa_2_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_v` varchar(25) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_v` varchar(25) NOT NULL DEFAULT '',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_2_1`
--

INSERT INTO `qa_2_1` (`id`, `user_id`, `type`, `q_1_yn`, `q_1_v`, `q_1`, `q_1_pl`, `q_1_status`, `q_2_yn`, `q_2_v`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '-', '0', '', 1, 1, '-', '3', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_2_2`
--

DROP TABLE IF EXISTS `qa_2_2`;
CREATE TABLE IF NOT EXISTS `qa_2_2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_2_2`
--

INSERT INTO `qa_2_2` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '0,1,0', 1, 1, '0,1,0', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_2_3`
--

DROP TABLE IF EXISTS `qa_2_3`;
CREATE TABLE IF NOT EXISTS `qa_2_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_2_3`
--

INSERT INTO `qa_2_3` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '0,1', 1, 1, '0,1', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_2_4`
--

DROP TABLE IF EXISTS `qa_2_4`;
CREATE TABLE IF NOT EXISTS `qa_2_4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_min` int(10) NOT NULL DEFAULT '0',
  `q_1_max` int(10) NOT NULL DEFAULT '0',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_min` int(10) NOT NULL DEFAULT '0',
  `q_2_max` int(10) NOT NULL DEFAULT '0',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_2_4`
--

INSERT INTO `qa_2_4` (`id`, `user_id`, `type`, `q_1_min`, `q_1_max`, `q_1_pl`, `q_1_status`, `q_2_min`, `q_2_max`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 26, 52, 1, 1, 19, 49, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_2_5`
--

DROP TABLE IF EXISTS `qa_2_5`;
CREATE TABLE IF NOT EXISTS `qa_2_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_5`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_6`
--

DROP TABLE IF EXISTS `qa_2_6`;
CREATE TABLE IF NOT EXISTS `qa_2_6` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_6`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_7`
--

DROP TABLE IF EXISTS `qa_2_7`;
CREATE TABLE IF NOT EXISTS `qa_2_7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_7`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_8`
--

DROP TABLE IF EXISTS `qa_2_8`;
CREATE TABLE IF NOT EXISTS `qa_2_8` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_8`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_9`
--

DROP TABLE IF EXISTS `qa_2_9`;
CREATE TABLE IF NOT EXISTS `qa_2_9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_9`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_10`
--

DROP TABLE IF EXISTS `qa_2_10`;
CREATE TABLE IF NOT EXISTS `qa_2_10` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_10`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_11`
--

DROP TABLE IF EXISTS `qa_2_11`;
CREATE TABLE IF NOT EXISTS `qa_2_11` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_11`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_12`
--

DROP TABLE IF EXISTS `qa_2_12`;
CREATE TABLE IF NOT EXISTS `qa_2_12` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_12`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_13`
--

DROP TABLE IF EXISTS `qa_2_13`;
CREATE TABLE IF NOT EXISTS `qa_2_13` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(5) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(5) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(5) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(5) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_13`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_14`
--

DROP TABLE IF EXISTS `qa_2_14`;
CREATE TABLE IF NOT EXISTS `qa_2_14` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_14`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_15`
--

DROP TABLE IF EXISTS `qa_2_15`;
CREATE TABLE IF NOT EXISTS `qa_2_15` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_15`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_16`
--

DROP TABLE IF EXISTS `qa_2_16`;
CREATE TABLE IF NOT EXISTS `qa_2_16` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_16`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_17`
--

DROP TABLE IF EXISTS `qa_2_17`;
CREATE TABLE IF NOT EXISTS `qa_2_17` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_17`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_18`
--

DROP TABLE IF EXISTS `qa_2_18`;
CREATE TABLE IF NOT EXISTS `qa_2_18` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_18`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_19`
--

DROP TABLE IF EXISTS `qa_2_19`;
CREATE TABLE IF NOT EXISTS `qa_2_19` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_19`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_20`
--

DROP TABLE IF EXISTS `qa_2_20`;
CREATE TABLE IF NOT EXISTS `qa_2_20` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_20`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_21`
--

DROP TABLE IF EXISTS `qa_2_21`;
CREATE TABLE IF NOT EXISTS `qa_2_21` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_21`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_22`
--

DROP TABLE IF EXISTS `qa_2_22`;
CREATE TABLE IF NOT EXISTS `qa_2_22` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_22`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_23`
--

DROP TABLE IF EXISTS `qa_2_23`;
CREATE TABLE IF NOT EXISTS `qa_2_23` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_23`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_24`
--

DROP TABLE IF EXISTS `qa_2_24`;
CREATE TABLE IF NOT EXISTS `qa_2_24` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(50) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(50) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_24`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_25`
--

DROP TABLE IF EXISTS `qa_2_25`;
CREATE TABLE IF NOT EXISTS `qa_2_25` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_25`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_26`
--

DROP TABLE IF EXISTS `qa_2_26`;
CREATE TABLE IF NOT EXISTS `qa_2_26` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_26`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_27`
--

DROP TABLE IF EXISTS `qa_2_27`;
CREATE TABLE IF NOT EXISTS `qa_2_27` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_main_1` int(10) NOT NULL DEFAULT '0',
  `q_1_sub_1` int(10) NOT NULL DEFAULT '0',
  `q_1_subsub_1` int(10) NOT NULL DEFAULT '0',
  `q_1_main_2` int(10) NOT NULL DEFAULT '0',
  `q_1_sub_2` int(10) NOT NULL DEFAULT '0',
  `q_1_subsub_2` int(10) NOT NULL DEFAULT '0',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_main_1` int(10) NOT NULL DEFAULT '0',
  `q_2_sub_1` int(10) NOT NULL DEFAULT '0',
  `q_2_subsub_1` int(10) NOT NULL DEFAULT '0',
  `q_2_main_2` int(10) NOT NULL DEFAULT '0',
  `q_2_sub_2` int(10) NOT NULL DEFAULT '0',
  `q_2_subsub_2` int(10) NOT NULL DEFAULT '0',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_27`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_28`
--

DROP TABLE IF EXISTS `qa_2_28`;
CREATE TABLE IF NOT EXISTS `qa_2_28` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_hha_one` smallint(6) NOT NULL,
  `q_1_hha_two` smallint(6) NOT NULL,
  `q_1_hhb_one` smallint(6) NOT NULL,
  `q_1_hhb_two` smallint(6) NOT NULL,
  `q_1_hhc_one` smallint(6) NOT NULL,
  `q_1_hhc_two` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_hha_one` smallint(6) NOT NULL,
  `q_2_hha_two` smallint(6) NOT NULL,
  `q_2_hhb_one` smallint(6) NOT NULL,
  `q_2_hhb_two` smallint(6) NOT NULL,
  `q_2_hhc_one` smallint(6) NOT NULL,
  `q_2_hhc_two` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_28`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_29`
--

DROP TABLE IF EXISTS `qa_2_29`;
CREATE TABLE IF NOT EXISTS `qa_2_29` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_v_1` varchar(5) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(5) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(5) NOT NULL DEFAULT '',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(5) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_29`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_30`
--

DROP TABLE IF EXISTS `qa_2_30`;
CREATE TABLE IF NOT EXISTS `qa_2_30` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_v_1` varchar(5) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(5) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(5) NOT NULL DEFAULT '',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(5) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_30`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_31`
--

DROP TABLE IF EXISTS `qa_2_31`;
CREATE TABLE IF NOT EXISTS `qa_2_31` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn_1` varchar(1) NOT NULL,
  `q_1_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn_1` varchar(1) NOT NULL,
  `q_2_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_31`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_32`
--

DROP TABLE IF EXISTS `qa_2_32`;
CREATE TABLE IF NOT EXISTS `qa_2_32` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn_1` varchar(1) NOT NULL,
  `q_1_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn_1` varchar(1) NOT NULL,
  `q_2_yn_2` varchar(1) NOT NULL DEFAULT '',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_32`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_33`
--

DROP TABLE IF EXISTS `qa_2_33`;
CREATE TABLE IF NOT EXISTS `qa_2_33` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_33`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_34`
--

DROP TABLE IF EXISTS `qa_2_34`;
CREATE TABLE IF NOT EXISTS `qa_2_34` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_34`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_35`
--

DROP TABLE IF EXISTS `qa_2_35`;
CREATE TABLE IF NOT EXISTS `qa_2_35` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_35`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_36`
--

DROP TABLE IF EXISTS `qa_2_36`;
CREATE TABLE IF NOT EXISTS `qa_2_36` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_36`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_37`
--

DROP TABLE IF EXISTS `qa_2_37`;
CREATE TABLE IF NOT EXISTS `qa_2_37` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_min` int(10) NOT NULL DEFAULT '0',
  `q_1_max` int(10) NOT NULL DEFAULT '0',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_min` int(10) NOT NULL DEFAULT '0',
  `q_2_max` int(10) NOT NULL DEFAULT '0',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_37`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_38`
--

DROP TABLE IF EXISTS `qa_2_38`;
CREATE TABLE IF NOT EXISTS `qa_2_38` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_min` int(10) NOT NULL DEFAULT '0',
  `q_1_max` int(10) NOT NULL DEFAULT '0',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_min` int(10) NOT NULL DEFAULT '0',
  `q_2_max` int(10) NOT NULL DEFAULT '0',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_38`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_39`
--

DROP TABLE IF EXISTS `qa_2_39`;
CREATE TABLE IF NOT EXISTS `qa_2_39` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_39`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_40`
--

DROP TABLE IF EXISTS `qa_2_40`;
CREATE TABLE IF NOT EXISTS `qa_2_40` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_40`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_41`
--

DROP TABLE IF EXISTS `qa_2_41`;
CREATE TABLE IF NOT EXISTS `qa_2_41` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_41`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_42`
--

DROP TABLE IF EXISTS `qa_2_42`;
CREATE TABLE IF NOT EXISTS `qa_2_42` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_42`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_43`
--

DROP TABLE IF EXISTS `qa_2_43`;
CREATE TABLE IF NOT EXISTS `qa_2_43` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_43`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_44`
--

DROP TABLE IF EXISTS `qa_2_44`;
CREATE TABLE IF NOT EXISTS `qa_2_44` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_44`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_45`
--

DROP TABLE IF EXISTS `qa_2_45`;
CREATE TABLE IF NOT EXISTS `qa_2_45` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_45`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_46`
--

DROP TABLE IF EXISTS `qa_2_46`;
CREATE TABLE IF NOT EXISTS `qa_2_46` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_46`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_47`
--

DROP TABLE IF EXISTS `qa_2_47`;
CREATE TABLE IF NOT EXISTS `qa_2_47` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_47`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_48`
--

DROP TABLE IF EXISTS `qa_2_48`;
CREATE TABLE IF NOT EXISTS `qa_2_48` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_48`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_49`
--

DROP TABLE IF EXISTS `qa_2_49`;
CREATE TABLE IF NOT EXISTS `qa_2_49` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_49`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_50`
--

DROP TABLE IF EXISTS `qa_2_50`;
CREATE TABLE IF NOT EXISTS `qa_2_50` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_50`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_51`
--

DROP TABLE IF EXISTS `qa_2_51`;
CREATE TABLE IF NOT EXISTS `qa_2_51` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_51`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_52`
--

DROP TABLE IF EXISTS `qa_2_52`;
CREATE TABLE IF NOT EXISTS `qa_2_52` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_52`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_53`
--

DROP TABLE IF EXISTS `qa_2_53`;
CREATE TABLE IF NOT EXISTS `qa_2_53` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_53`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_54`
--

DROP TABLE IF EXISTS `qa_2_54`;
CREATE TABLE IF NOT EXISTS `qa_2_54` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_54`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_55`
--

DROP TABLE IF EXISTS `qa_2_55`;
CREATE TABLE IF NOT EXISTS `qa_2_55` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_55`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_56`
--

DROP TABLE IF EXISTS `qa_2_56`;
CREATE TABLE IF NOT EXISTS `qa_2_56` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_2_56`
--

INSERT INTO `qa_2_56` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '0', 3, 1, '1', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_2_57`
--

DROP TABLE IF EXISTS `qa_2_57`;
CREATE TABLE IF NOT EXISTS `qa_2_57` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_2_57`
--

INSERT INTO `qa_2_57` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '', 3, 1, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_2_58`
--

DROP TABLE IF EXISTS `qa_2_58`;
CREATE TABLE IF NOT EXISTS `qa_2_58` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_58`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_59`
--

DROP TABLE IF EXISTS `qa_2_59`;
CREATE TABLE IF NOT EXISTS `qa_2_59` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_59`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_60`
--

DROP TABLE IF EXISTS `qa_2_60`;
CREATE TABLE IF NOT EXISTS `qa_2_60` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_60`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_61`
--

DROP TABLE IF EXISTS `qa_2_61`;
CREATE TABLE IF NOT EXISTS `qa_2_61` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_61`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_62`
--

DROP TABLE IF EXISTS `qa_2_62`;
CREATE TABLE IF NOT EXISTS `qa_2_62` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_62`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_63`
--

DROP TABLE IF EXISTS `qa_2_63`;
CREATE TABLE IF NOT EXISTS `qa_2_63` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_63`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_64`
--

DROP TABLE IF EXISTS `qa_2_64`;
CREATE TABLE IF NOT EXISTS `qa_2_64` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_2_64`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_2_65`
--

DROP TABLE IF EXISTS `qa_2_65`;
CREATE TABLE IF NOT EXISTS `qa_2_65` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_2_65`
--

INSERT INTO `qa_2_65` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '', 3, 1, '', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_1`
--

DROP TABLE IF EXISTS `qa_3_1`;
CREATE TABLE IF NOT EXISTS `qa_3_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `qa_3_1`
--

INSERT INTO `qa_3_1` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 2, 3, 1, 1, 6, 1, 1),
(2, 2, 1, 0, 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_2`
--

DROP TABLE IF EXISTS `qa_3_2`;
CREATE TABLE IF NOT EXISTS `qa_3_2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `qa_3_2`
--

INSERT INTO `qa_3_2` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 2, 5, 1, 1, 4, 1, 1),
(2, 2, 1, 0, 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_3`
--

DROP TABLE IF EXISTS `qa_3_3`;
CREATE TABLE IF NOT EXISTS `qa_3_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_3`
--

INSERT INTO `qa_3_3` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 0, 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_4`
--

DROP TABLE IF EXISTS `qa_3_4`;
CREATE TABLE IF NOT EXISTS `qa_3_4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_4`
--

INSERT INTO `qa_3_4` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 0, 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_5`
--

DROP TABLE IF EXISTS `qa_3_5`;
CREATE TABLE IF NOT EXISTS `qa_3_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_5`
--

INSERT INTO `qa_3_5` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 0, 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_6`
--

DROP TABLE IF EXISTS `qa_3_6`;
CREATE TABLE IF NOT EXISTS `qa_3_6` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_6`
--

INSERT INTO `qa_3_6` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 0, 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_7`
--

DROP TABLE IF EXISTS `qa_3_7`;
CREATE TABLE IF NOT EXISTS `qa_3_7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_7`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_8`
--

DROP TABLE IF EXISTS `qa_3_8`;
CREATE TABLE IF NOT EXISTS `qa_3_8` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_8`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_9`
--

DROP TABLE IF EXISTS `qa_3_9`;
CREATE TABLE IF NOT EXISTS `qa_3_9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_9`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_10`
--

DROP TABLE IF EXISTS `qa_3_10`;
CREATE TABLE IF NOT EXISTS `qa_3_10` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_10`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_11`
--

DROP TABLE IF EXISTS `qa_3_11`;
CREATE TABLE IF NOT EXISTS `qa_3_11` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_11`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_12`
--

DROP TABLE IF EXISTS `qa_3_12`;
CREATE TABLE IF NOT EXISTS `qa_3_12` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_12`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_13`
--

DROP TABLE IF EXISTS `qa_3_13`;
CREATE TABLE IF NOT EXISTS `qa_3_13` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_13`
--

INSERT INTO `qa_3_13` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 0, 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_14`
--

DROP TABLE IF EXISTS `qa_3_14`;
CREATE TABLE IF NOT EXISTS `qa_3_14` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_14`
--

INSERT INTO `qa_3_14` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 0, 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_15`
--

DROP TABLE IF EXISTS `qa_3_15`;
CREATE TABLE IF NOT EXISTS `qa_3_15` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_15`
--

INSERT INTO `qa_3_15` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 0, 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_16`
--

DROP TABLE IF EXISTS `qa_3_16`;
CREATE TABLE IF NOT EXISTS `qa_3_16` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_16`
--

INSERT INTO `qa_3_16` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 0, 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_17`
--

DROP TABLE IF EXISTS `qa_3_17`;
CREATE TABLE IF NOT EXISTS `qa_3_17` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_17`
--

INSERT INTO `qa_3_17` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 6, 1, 1, 5, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_18`
--

DROP TABLE IF EXISTS `qa_3_18`;
CREATE TABLE IF NOT EXISTS `qa_3_18` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_3_18`
--

INSERT INTO `qa_3_18` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 4, 1, 1, 6, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_3_19`
--

DROP TABLE IF EXISTS `qa_3_19`;
CREATE TABLE IF NOT EXISTS `qa_3_19` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_19`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_20`
--

DROP TABLE IF EXISTS `qa_3_20`;
CREATE TABLE IF NOT EXISTS `qa_3_20` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_20`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_21`
--

DROP TABLE IF EXISTS `qa_3_21`;
CREATE TABLE IF NOT EXISTS `qa_3_21` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_21`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_22`
--

DROP TABLE IF EXISTS `qa_3_22`;
CREATE TABLE IF NOT EXISTS `qa_3_22` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_22`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_23`
--

DROP TABLE IF EXISTS `qa_3_23`;
CREATE TABLE IF NOT EXISTS `qa_3_23` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_23`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_24`
--

DROP TABLE IF EXISTS `qa_3_24`;
CREATE TABLE IF NOT EXISTS `qa_3_24` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_24`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_25`
--

DROP TABLE IF EXISTS `qa_3_25`;
CREATE TABLE IF NOT EXISTS `qa_3_25` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_25`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_26`
--

DROP TABLE IF EXISTS `qa_3_26`;
CREATE TABLE IF NOT EXISTS `qa_3_26` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_26`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_27`
--

DROP TABLE IF EXISTS `qa_3_27`;
CREATE TABLE IF NOT EXISTS `qa_3_27` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_27`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_28`
--

DROP TABLE IF EXISTS `qa_3_28`;
CREATE TABLE IF NOT EXISTS `qa_3_28` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_28`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_29`
--

DROP TABLE IF EXISTS `qa_3_29`;
CREATE TABLE IF NOT EXISTS `qa_3_29` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_29`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_30`
--

DROP TABLE IF EXISTS `qa_3_30`;
CREATE TABLE IF NOT EXISTS `qa_3_30` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_30`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_31`
--

DROP TABLE IF EXISTS `qa_3_31`;
CREATE TABLE IF NOT EXISTS `qa_3_31` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_31`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_32`
--

DROP TABLE IF EXISTS `qa_3_32`;
CREATE TABLE IF NOT EXISTS `qa_3_32` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_32`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_33`
--

DROP TABLE IF EXISTS `qa_3_33`;
CREATE TABLE IF NOT EXISTS `qa_3_33` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_33`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_34`
--

DROP TABLE IF EXISTS `qa_3_34`;
CREATE TABLE IF NOT EXISTS `qa_3_34` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_34`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_35`
--

DROP TABLE IF EXISTS `qa_3_35`;
CREATE TABLE IF NOT EXISTS `qa_3_35` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_35`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_36`
--

DROP TABLE IF EXISTS `qa_3_36`;
CREATE TABLE IF NOT EXISTS `qa_3_36` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_36`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_37`
--

DROP TABLE IF EXISTS `qa_3_37`;
CREATE TABLE IF NOT EXISTS `qa_3_37` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_37`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_38`
--

DROP TABLE IF EXISTS `qa_3_38`;
CREATE TABLE IF NOT EXISTS `qa_3_38` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_38`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_39`
--

DROP TABLE IF EXISTS `qa_3_39`;
CREATE TABLE IF NOT EXISTS `qa_3_39` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_39`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_40`
--

DROP TABLE IF EXISTS `qa_3_40`;
CREATE TABLE IF NOT EXISTS `qa_3_40` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_40`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_41`
--

DROP TABLE IF EXISTS `qa_3_41`;
CREATE TABLE IF NOT EXISTS `qa_3_41` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_41`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_42`
--

DROP TABLE IF EXISTS `qa_3_42`;
CREATE TABLE IF NOT EXISTS `qa_3_42` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_42`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_43`
--

DROP TABLE IF EXISTS `qa_3_43`;
CREATE TABLE IF NOT EXISTS `qa_3_43` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_43`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_44`
--

DROP TABLE IF EXISTS `qa_3_44`;
CREATE TABLE IF NOT EXISTS `qa_3_44` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_44`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_45`
--

DROP TABLE IF EXISTS `qa_3_45`;
CREATE TABLE IF NOT EXISTS `qa_3_45` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_45`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_46`
--

DROP TABLE IF EXISTS `qa_3_46`;
CREATE TABLE IF NOT EXISTS `qa_3_46` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_46`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_47`
--

DROP TABLE IF EXISTS `qa_3_47`;
CREATE TABLE IF NOT EXISTS `qa_3_47` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_47`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_48`
--

DROP TABLE IF EXISTS `qa_3_48`;
CREATE TABLE IF NOT EXISTS `qa_3_48` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_48`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_49`
--

DROP TABLE IF EXISTS `qa_3_49`;
CREATE TABLE IF NOT EXISTS `qa_3_49` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_49`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_50`
--

DROP TABLE IF EXISTS `qa_3_50`;
CREATE TABLE IF NOT EXISTS `qa_3_50` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_50`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_51`
--

DROP TABLE IF EXISTS `qa_3_51`;
CREATE TABLE IF NOT EXISTS `qa_3_51` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_51`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_52`
--

DROP TABLE IF EXISTS `qa_3_52`;
CREATE TABLE IF NOT EXISTS `qa_3_52` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_52`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_53`
--

DROP TABLE IF EXISTS `qa_3_53`;
CREATE TABLE IF NOT EXISTS `qa_3_53` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_53`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_54`
--

DROP TABLE IF EXISTS `qa_3_54`;
CREATE TABLE IF NOT EXISTS `qa_3_54` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_54`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_55`
--

DROP TABLE IF EXISTS `qa_3_55`;
CREATE TABLE IF NOT EXISTS `qa_3_55` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_55`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_56`
--

DROP TABLE IF EXISTS `qa_3_56`;
CREATE TABLE IF NOT EXISTS `qa_3_56` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_56`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_57`
--

DROP TABLE IF EXISTS `qa_3_57`;
CREATE TABLE IF NOT EXISTS `qa_3_57` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_57`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_58`
--

DROP TABLE IF EXISTS `qa_3_58`;
CREATE TABLE IF NOT EXISTS `qa_3_58` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_58`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_59`
--

DROP TABLE IF EXISTS `qa_3_59`;
CREATE TABLE IF NOT EXISTS `qa_3_59` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_59`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_60`
--

DROP TABLE IF EXISTS `qa_3_60`;
CREATE TABLE IF NOT EXISTS `qa_3_60` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_60`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_61`
--

DROP TABLE IF EXISTS `qa_3_61`;
CREATE TABLE IF NOT EXISTS `qa_3_61` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_61`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_62`
--

DROP TABLE IF EXISTS `qa_3_62`;
CREATE TABLE IF NOT EXISTS `qa_3_62` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_62`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_63`
--

DROP TABLE IF EXISTS `qa_3_63`;
CREATE TABLE IF NOT EXISTS `qa_3_63` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_63`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_64`
--

DROP TABLE IF EXISTS `qa_3_64`;
CREATE TABLE IF NOT EXISTS `qa_3_64` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_64`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_3_65`
--

DROP TABLE IF EXISTS `qa_3_65`;
CREATE TABLE IF NOT EXISTS `qa_3_65` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` smallint(6) NOT NULL,
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_3_65`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_1`
--

DROP TABLE IF EXISTS `qa_4_1`;
CREATE TABLE IF NOT EXISTS `qa_4_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_4_1`
--

INSERT INTO `qa_4_1` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '0,0,0,0,0,1,0,0,0', 1, 1, '0,0,0,1,0,0,0,0,0', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_4_2`
--

DROP TABLE IF EXISTS `qa_4_2`;
CREATE TABLE IF NOT EXISTS `qa_4_2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_2`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_3`
--

DROP TABLE IF EXISTS `qa_4_3`;
CREATE TABLE IF NOT EXISTS `qa_4_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_3`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_4`
--

DROP TABLE IF EXISTS `qa_4_4`;
CREATE TABLE IF NOT EXISTS `qa_4_4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_4`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_5`
--

DROP TABLE IF EXISTS `qa_4_5`;
CREATE TABLE IF NOT EXISTS `qa_4_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_5`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_6`
--

DROP TABLE IF EXISTS `qa_4_6`;
CREATE TABLE IF NOT EXISTS `qa_4_6` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_6`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_7`
--

DROP TABLE IF EXISTS `qa_4_7`;
CREATE TABLE IF NOT EXISTS `qa_4_7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(5) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(5) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_7`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_8`
--

DROP TABLE IF EXISTS `qa_4_8`;
CREATE TABLE IF NOT EXISTS `qa_4_8` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_8`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_9`
--

DROP TABLE IF EXISTS `qa_4_9`;
CREATE TABLE IF NOT EXISTS `qa_4_9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_9`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_10`
--

DROP TABLE IF EXISTS `qa_4_10`;
CREATE TABLE IF NOT EXISTS `qa_4_10` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_10`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_11`
--

DROP TABLE IF EXISTS `qa_4_11`;
CREATE TABLE IF NOT EXISTS `qa_4_11` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_11`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_12`
--

DROP TABLE IF EXISTS `qa_4_12`;
CREATE TABLE IF NOT EXISTS `qa_4_12` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_12`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_13`
--

DROP TABLE IF EXISTS `qa_4_13`;
CREATE TABLE IF NOT EXISTS `qa_4_13` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_13`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_14`
--

DROP TABLE IF EXISTS `qa_4_14`;
CREATE TABLE IF NOT EXISTS `qa_4_14` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_14`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_15`
--

DROP TABLE IF EXISTS `qa_4_15`;
CREATE TABLE IF NOT EXISTS `qa_4_15` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_15`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_16`
--

DROP TABLE IF EXISTS `qa_4_16`;
CREATE TABLE IF NOT EXISTS `qa_4_16` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_16`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_17`
--

DROP TABLE IF EXISTS `qa_4_17`;
CREATE TABLE IF NOT EXISTS `qa_4_17` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_17`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_18`
--

DROP TABLE IF EXISTS `qa_4_18`;
CREATE TABLE IF NOT EXISTS `qa_4_18` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` smallint(6) NOT NULL,
  `q_2_v_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_18`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_19`
--

DROP TABLE IF EXISTS `qa_4_19`;
CREATE TABLE IF NOT EXISTS `qa_4_19` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_19`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_20`
--

DROP TABLE IF EXISTS `qa_4_20`;
CREATE TABLE IF NOT EXISTS `qa_4_20` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_20`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_21`
--

DROP TABLE IF EXISTS `qa_4_21`;
CREATE TABLE IF NOT EXISTS `qa_4_21` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_21`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_22`
--

DROP TABLE IF EXISTS `qa_4_22`;
CREATE TABLE IF NOT EXISTS `qa_4_22` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_22`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_23`
--

DROP TABLE IF EXISTS `qa_4_23`;
CREATE TABLE IF NOT EXISTS `qa_4_23` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_23`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_24`
--

DROP TABLE IF EXISTS `qa_4_24`;
CREATE TABLE IF NOT EXISTS `qa_4_24` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_24`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_25`
--

DROP TABLE IF EXISTS `qa_4_25`;
CREATE TABLE IF NOT EXISTS `qa_4_25` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_25`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_26`
--

DROP TABLE IF EXISTS `qa_4_26`;
CREATE TABLE IF NOT EXISTS `qa_4_26` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_26`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_27`
--

DROP TABLE IF EXISTS `qa_4_27`;
CREATE TABLE IF NOT EXISTS `qa_4_27` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_27`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_28`
--

DROP TABLE IF EXISTS `qa_4_28`;
CREATE TABLE IF NOT EXISTS `qa_4_28` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_28`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_29`
--

DROP TABLE IF EXISTS `qa_4_29`;
CREATE TABLE IF NOT EXISTS `qa_4_29` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_29`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_30`
--

DROP TABLE IF EXISTS `qa_4_30`;
CREATE TABLE IF NOT EXISTS `qa_4_30` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_30`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_31`
--

DROP TABLE IF EXISTS `qa_4_31`;
CREATE TABLE IF NOT EXISTS `qa_4_31` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_31`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_32`
--

DROP TABLE IF EXISTS `qa_4_32`;
CREATE TABLE IF NOT EXISTS `qa_4_32` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_32`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_33`
--

DROP TABLE IF EXISTS `qa_4_33`;
CREATE TABLE IF NOT EXISTS `qa_4_33` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_33`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_34`
--

DROP TABLE IF EXISTS `qa_4_34`;
CREATE TABLE IF NOT EXISTS `qa_4_34` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_34`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_35`
--

DROP TABLE IF EXISTS `qa_4_35`;
CREATE TABLE IF NOT EXISTS `qa_4_35` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_35`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_36`
--

DROP TABLE IF EXISTS `qa_4_36`;
CREATE TABLE IF NOT EXISTS `qa_4_36` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_36`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_37`
--

DROP TABLE IF EXISTS `qa_4_37`;
CREATE TABLE IF NOT EXISTS `qa_4_37` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_37`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_38`
--

DROP TABLE IF EXISTS `qa_4_38`;
CREATE TABLE IF NOT EXISTS `qa_4_38` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_38`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_39`
--

DROP TABLE IF EXISTS `qa_4_39`;
CREATE TABLE IF NOT EXISTS `qa_4_39` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_39`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_40`
--

DROP TABLE IF EXISTS `qa_4_40`;
CREATE TABLE IF NOT EXISTS `qa_4_40` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` smallint(6) NOT NULL,
  `q_2_v_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_40`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_41`
--

DROP TABLE IF EXISTS `qa_4_41`;
CREATE TABLE IF NOT EXISTS `qa_4_41` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_41`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_42`
--

DROP TABLE IF EXISTS `qa_4_42`;
CREATE TABLE IF NOT EXISTS `qa_4_42` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_42`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_43`
--

DROP TABLE IF EXISTS `qa_4_43`;
CREATE TABLE IF NOT EXISTS `qa_4_43` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_43`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_44`
--

DROP TABLE IF EXISTS `qa_4_44`;
CREATE TABLE IF NOT EXISTS `qa_4_44` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_44`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_45`
--

DROP TABLE IF EXISTS `qa_4_45`;
CREATE TABLE IF NOT EXISTS `qa_4_45` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_45`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_46`
--

DROP TABLE IF EXISTS `qa_4_46`;
CREATE TABLE IF NOT EXISTS `qa_4_46` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_46`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_47`
--

DROP TABLE IF EXISTS `qa_4_47`;
CREATE TABLE IF NOT EXISTS `qa_4_47` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` smallint(6) NOT NULL,
  `q_2_v_2` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_47`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_48`
--

DROP TABLE IF EXISTS `qa_4_48`;
CREATE TABLE IF NOT EXISTS `qa_4_48` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_48`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_49`
--

DROP TABLE IF EXISTS `qa_4_49`;
CREATE TABLE IF NOT EXISTS `qa_4_49` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_49`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_50`
--

DROP TABLE IF EXISTS `qa_4_50`;
CREATE TABLE IF NOT EXISTS `qa_4_50` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` smallint(6) NOT NULL,
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_50`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_51`
--

DROP TABLE IF EXISTS `qa_4_51`;
CREATE TABLE IF NOT EXISTS `qa_4_51` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_5` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_6` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` smallint(6) NOT NULL,
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_5` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_6` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_51`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_52`
--

DROP TABLE IF EXISTS `qa_4_52`;
CREATE TABLE IF NOT EXISTS `qa_4_52` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_52`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_53`
--

DROP TABLE IF EXISTS `qa_4_53`;
CREATE TABLE IF NOT EXISTS `qa_4_53` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_53`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_54`
--

DROP TABLE IF EXISTS `qa_4_54`;
CREATE TABLE IF NOT EXISTS `qa_4_54` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_54`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_55`
--

DROP TABLE IF EXISTS `qa_4_55`;
CREATE TABLE IF NOT EXISTS `qa_4_55` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_55`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_56`
--

DROP TABLE IF EXISTS `qa_4_56`;
CREATE TABLE IF NOT EXISTS `qa_4_56` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_56`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_57`
--

DROP TABLE IF EXISTS `qa_4_57`;
CREATE TABLE IF NOT EXISTS `qa_4_57` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_57`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_58`
--

DROP TABLE IF EXISTS `qa_4_58`;
CREATE TABLE IF NOT EXISTS `qa_4_58` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_58`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_59`
--

DROP TABLE IF EXISTS `qa_4_59`;
CREATE TABLE IF NOT EXISTS `qa_4_59` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_59`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_60`
--

DROP TABLE IF EXISTS `qa_4_60`;
CREATE TABLE IF NOT EXISTS `qa_4_60` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_60`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_61`
--

DROP TABLE IF EXISTS `qa_4_61`;
CREATE TABLE IF NOT EXISTS `qa_4_61` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_61`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_62`
--

DROP TABLE IF EXISTS `qa_4_62`;
CREATE TABLE IF NOT EXISTS `qa_4_62` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_62`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_4_63`
--

DROP TABLE IF EXISTS `qa_4_63`;
CREATE TABLE IF NOT EXISTS `qa_4_63` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_4_63`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_1`
--

DROP TABLE IF EXISTS `qa_5_1`;
CREATE TABLE IF NOT EXISTS `qa_5_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(1) NOT NULL DEFAULT '',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_5_1`
--

INSERT INTO `qa_5_1` (`id`, `user_id`, `type`, `q_1_yn`, `q_1`, `q_1_pl`, `q_1_status`) VALUES
(1, 2, 1, 'Y', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_5_2`
--

DROP TABLE IF EXISTS `qa_5_2`;
CREATE TABLE IF NOT EXISTS `qa_5_2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_5_2`
--

INSERT INTO `qa_5_2` (`id`, `user_id`, `type`, `q_1_yn_1`, `q_1_pl`, `q_1_status`, `q_2_yn_1`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, 'N', 1, 1, 'N', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_5_3`
--

DROP TABLE IF EXISTS `qa_5_3`;
CREATE TABLE IF NOT EXISTS `qa_5_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_5_3`
--

INSERT INTO `qa_5_3` (`id`, `user_id`, `type`, `q_1_v_1`, `q_1_v_2`, `q_1_pl`, `q_1_status`, `q_2_v_1`, `q_2_v_2`, `q_2_pl`, `q_2_status`) VALUES
(1, 2, 1, '-', '-', 1, 0, '-', '-', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_5_4`
--

DROP TABLE IF EXISTS `qa_5_4`;
CREATE TABLE IF NOT EXISTS `qa_5_4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_5_4`
--

INSERT INTO `qa_5_4` (`id`, `user_id`, `type`, `q_1_v_1`, `q_1_v_2`, `q_1_pl`, `q_1_status`) VALUES
(1, 2, 1, '-', '-', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_5_5`
--

DROP TABLE IF EXISTS `qa_5_5`;
CREATE TABLE IF NOT EXISTS `qa_5_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_5_5`
--

INSERT INTO `qa_5_5` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`) VALUES
(1, 2, 1, '0,0,0,0,0,0,0', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_5_6`
--

DROP TABLE IF EXISTS `qa_5_6`;
CREATE TABLE IF NOT EXISTS `qa_5_6` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_5_6`
--

INSERT INTO `qa_5_6` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`) VALUES
(1, 2, 1, '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_5_7`
--

DROP TABLE IF EXISTS `qa_5_7`;
CREATE TABLE IF NOT EXISTS `qa_5_7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_5_7`
--

INSERT INTO `qa_5_7` (`id`, `user_id`, `type`, `pie_1`, `pie_1_mp`, `q_1_pl`, `q_1_status`) VALUES
(1, 2, 1, '-', '-', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_5_8`
--

DROP TABLE IF EXISTS `qa_5_8`;
CREATE TABLE IF NOT EXISTS `qa_5_8` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_8`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_9`
--

DROP TABLE IF EXISTS `qa_5_9`;
CREATE TABLE IF NOT EXISTS `qa_5_9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_9`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_10`
--

DROP TABLE IF EXISTS `qa_5_10`;
CREATE TABLE IF NOT EXISTS `qa_5_10` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_10`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_11`
--

DROP TABLE IF EXISTS `qa_5_11`;
CREATE TABLE IF NOT EXISTS `qa_5_11` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_11`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_12`
--

DROP TABLE IF EXISTS `qa_5_12`;
CREATE TABLE IF NOT EXISTS `qa_5_12` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_12`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_13`
--

DROP TABLE IF EXISTS `qa_5_13`;
CREATE TABLE IF NOT EXISTS `qa_5_13` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_13`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_14`
--

DROP TABLE IF EXISTS `qa_5_14`;
CREATE TABLE IF NOT EXISTS `qa_5_14` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_14`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_15`
--

DROP TABLE IF EXISTS `qa_5_15`;
CREATE TABLE IF NOT EXISTS `qa_5_15` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_15`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_16`
--

DROP TABLE IF EXISTS `qa_5_16`;
CREATE TABLE IF NOT EXISTS `qa_5_16` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_16`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_17`
--

DROP TABLE IF EXISTS `qa_5_17`;
CREATE TABLE IF NOT EXISTS `qa_5_17` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_17`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_18`
--

DROP TABLE IF EXISTS `qa_5_18`;
CREATE TABLE IF NOT EXISTS `qa_5_18` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_18`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_19`
--

DROP TABLE IF EXISTS `qa_5_19`;
CREATE TABLE IF NOT EXISTS `qa_5_19` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_19`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_20`
--

DROP TABLE IF EXISTS `qa_5_20`;
CREATE TABLE IF NOT EXISTS `qa_5_20` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_20`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_21`
--

DROP TABLE IF EXISTS `qa_5_21`;
CREATE TABLE IF NOT EXISTS `qa_5_21` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_21`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_22`
--

DROP TABLE IF EXISTS `qa_5_22`;
CREATE TABLE IF NOT EXISTS `qa_5_22` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_22`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_23`
--

DROP TABLE IF EXISTS `qa_5_23`;
CREATE TABLE IF NOT EXISTS `qa_5_23` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_23`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_24`
--

DROP TABLE IF EXISTS `qa_5_24`;
CREATE TABLE IF NOT EXISTS `qa_5_24` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_24`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_25`
--

DROP TABLE IF EXISTS `qa_5_25`;
CREATE TABLE IF NOT EXISTS `qa_5_25` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_25`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_26`
--

DROP TABLE IF EXISTS `qa_5_26`;
CREATE TABLE IF NOT EXISTS `qa_5_26` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_26`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_27`
--

DROP TABLE IF EXISTS `qa_5_27`;
CREATE TABLE IF NOT EXISTS `qa_5_27` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_27`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_28`
--

DROP TABLE IF EXISTS `qa_5_28`;
CREATE TABLE IF NOT EXISTS `qa_5_28` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_28`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_29`
--

DROP TABLE IF EXISTS `qa_5_29`;
CREATE TABLE IF NOT EXISTS `qa_5_29` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_29`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_30`
--

DROP TABLE IF EXISTS `qa_5_30`;
CREATE TABLE IF NOT EXISTS `qa_5_30` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_30`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_31`
--

DROP TABLE IF EXISTS `qa_5_31`;
CREATE TABLE IF NOT EXISTS `qa_5_31` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_31`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_32`
--

DROP TABLE IF EXISTS `qa_5_32`;
CREATE TABLE IF NOT EXISTS `qa_5_32` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_32`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_33`
--

DROP TABLE IF EXISTS `qa_5_33`;
CREATE TABLE IF NOT EXISTS `qa_5_33` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_33`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_34`
--

DROP TABLE IF EXISTS `qa_5_34`;
CREATE TABLE IF NOT EXISTS `qa_5_34` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_34`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_35`
--

DROP TABLE IF EXISTS `qa_5_35`;
CREATE TABLE IF NOT EXISTS `qa_5_35` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_35`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_36`
--

DROP TABLE IF EXISTS `qa_5_36`;
CREATE TABLE IF NOT EXISTS `qa_5_36` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_36`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_37`
--

DROP TABLE IF EXISTS `qa_5_37`;
CREATE TABLE IF NOT EXISTS `qa_5_37` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_37`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_38`
--

DROP TABLE IF EXISTS `qa_5_38`;
CREATE TABLE IF NOT EXISTS `qa_5_38` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_38`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_39`
--

DROP TABLE IF EXISTS `qa_5_39`;
CREATE TABLE IF NOT EXISTS `qa_5_39` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_39`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_40`
--

DROP TABLE IF EXISTS `qa_5_40`;
CREATE TABLE IF NOT EXISTS `qa_5_40` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_40`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_41`
--

DROP TABLE IF EXISTS `qa_5_41`;
CREATE TABLE IF NOT EXISTS `qa_5_41` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_41`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_42`
--

DROP TABLE IF EXISTS `qa_5_42`;
CREATE TABLE IF NOT EXISTS `qa_5_42` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_42`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_43`
--

DROP TABLE IF EXISTS `qa_5_43`;
CREATE TABLE IF NOT EXISTS `qa_5_43` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_43`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_44`
--

DROP TABLE IF EXISTS `qa_5_44`;
CREATE TABLE IF NOT EXISTS `qa_5_44` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_44`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_45`
--

DROP TABLE IF EXISTS `qa_5_45`;
CREATE TABLE IF NOT EXISTS `qa_5_45` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_45`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_46`
--

DROP TABLE IF EXISTS `qa_5_46`;
CREATE TABLE IF NOT EXISTS `qa_5_46` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_46`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_47`
--

DROP TABLE IF EXISTS `qa_5_47`;
CREATE TABLE IF NOT EXISTS `qa_5_47` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_47`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_48`
--

DROP TABLE IF EXISTS `qa_5_48`;
CREATE TABLE IF NOT EXISTS `qa_5_48` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_48`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_49`
--

DROP TABLE IF EXISTS `qa_5_49`;
CREATE TABLE IF NOT EXISTS `qa_5_49` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_49`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_50`
--

DROP TABLE IF EXISTS `qa_5_50`;
CREATE TABLE IF NOT EXISTS `qa_5_50` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_50`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_51`
--

DROP TABLE IF EXISTS `qa_5_51`;
CREATE TABLE IF NOT EXISTS `qa_5_51` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_51`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_52`
--

DROP TABLE IF EXISTS `qa_5_52`;
CREATE TABLE IF NOT EXISTS `qa_5_52` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_52`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_53`
--

DROP TABLE IF EXISTS `qa_5_53`;
CREATE TABLE IF NOT EXISTS `qa_5_53` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_53`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_54`
--

DROP TABLE IF EXISTS `qa_5_54`;
CREATE TABLE IF NOT EXISTS `qa_5_54` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_54`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_55`
--

DROP TABLE IF EXISTS `qa_5_55`;
CREATE TABLE IF NOT EXISTS `qa_5_55` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_55`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_56`
--

DROP TABLE IF EXISTS `qa_5_56`;
CREATE TABLE IF NOT EXISTS `qa_5_56` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_56`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_57`
--

DROP TABLE IF EXISTS `qa_5_57`;
CREATE TABLE IF NOT EXISTS `qa_5_57` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_57`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_58`
--

DROP TABLE IF EXISTS `qa_5_58`;
CREATE TABLE IF NOT EXISTS `qa_5_58` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_5` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_4` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_5` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0' COMMENT 'sub question progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_58`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_59`
--

DROP TABLE IF EXISTS `qa_5_59`;
CREATE TABLE IF NOT EXISTS `qa_5_59` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_59`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_5_60`
--

DROP TABLE IF EXISTS `qa_5_60`;
CREATE TABLE IF NOT EXISTS `qa_5_60` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_5_60`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_1`
--

DROP TABLE IF EXISTS `qa_6_1`;
CREATE TABLE IF NOT EXISTS `qa_6_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_1`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_2`
--

DROP TABLE IF EXISTS `qa_6_2`;
CREATE TABLE IF NOT EXISTS `qa_6_2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_2`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_3`
--

DROP TABLE IF EXISTS `qa_6_3`;
CREATE TABLE IF NOT EXISTS `qa_6_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_3`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_4`
--

DROP TABLE IF EXISTS `qa_6_4`;
CREATE TABLE IF NOT EXISTS `qa_6_4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_4`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_5`
--

DROP TABLE IF EXISTS `qa_6_5`;
CREATE TABLE IF NOT EXISTS `qa_6_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_5`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_6`
--

DROP TABLE IF EXISTS `qa_6_6`;
CREATE TABLE IF NOT EXISTS `qa_6_6` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_6`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_7`
--

DROP TABLE IF EXISTS `qa_6_7`;
CREATE TABLE IF NOT EXISTS `qa_6_7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_7`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_8`
--

DROP TABLE IF EXISTS `qa_6_8`;
CREATE TABLE IF NOT EXISTS `qa_6_8` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_8`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_9`
--

DROP TABLE IF EXISTS `qa_6_9`;
CREATE TABLE IF NOT EXISTS `qa_6_9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_9`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_10`
--

DROP TABLE IF EXISTS `qa_6_10`;
CREATE TABLE IF NOT EXISTS `qa_6_10` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_10`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_11`
--

DROP TABLE IF EXISTS `qa_6_11`;
CREATE TABLE IF NOT EXISTS `qa_6_11` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_11`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_12`
--

DROP TABLE IF EXISTS `qa_6_12`;
CREATE TABLE IF NOT EXISTS `qa_6_12` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_12`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_13`
--

DROP TABLE IF EXISTS `qa_6_13`;
CREATE TABLE IF NOT EXISTS `qa_6_13` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_13`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_14`
--

DROP TABLE IF EXISTS `qa_6_14`;
CREATE TABLE IF NOT EXISTS `qa_6_14` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_14`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_15`
--

DROP TABLE IF EXISTS `qa_6_15`;
CREATE TABLE IF NOT EXISTS `qa_6_15` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_15`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_16`
--

DROP TABLE IF EXISTS `qa_6_16`;
CREATE TABLE IF NOT EXISTS `qa_6_16` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_16`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_17`
--

DROP TABLE IF EXISTS `qa_6_17`;
CREATE TABLE IF NOT EXISTS `qa_6_17` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_17`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_18`
--

DROP TABLE IF EXISTS `qa_6_18`;
CREATE TABLE IF NOT EXISTS `qa_6_18` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_18`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_19`
--

DROP TABLE IF EXISTS `qa_6_19`;
CREATE TABLE IF NOT EXISTS `qa_6_19` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_19`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_20`
--

DROP TABLE IF EXISTS `qa_6_20`;
CREATE TABLE IF NOT EXISTS `qa_6_20` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_20`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_21`
--

DROP TABLE IF EXISTS `qa_6_21`;
CREATE TABLE IF NOT EXISTS `qa_6_21` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_21`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_22`
--

DROP TABLE IF EXISTS `qa_6_22`;
CREATE TABLE IF NOT EXISTS `qa_6_22` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_22`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_23`
--

DROP TABLE IF EXISTS `qa_6_23`;
CREATE TABLE IF NOT EXISTS `qa_6_23` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_3` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_23`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_24`
--

DROP TABLE IF EXISTS `qa_6_24`;
CREATE TABLE IF NOT EXISTS `qa_6_24` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_yn` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_yn` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_24`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_25`
--

DROP TABLE IF EXISTS `qa_6_25`;
CREATE TABLE IF NOT EXISTS `qa_6_25` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_25`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_26`
--

DROP TABLE IF EXISTS `qa_6_26`;
CREATE TABLE IF NOT EXISTS `qa_6_26` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_26`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_27`
--

DROP TABLE IF EXISTS `qa_6_27`;
CREATE TABLE IF NOT EXISTS `qa_6_27` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_27`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_28`
--

DROP TABLE IF EXISTS `qa_6_28`;
CREATE TABLE IF NOT EXISTS `qa_6_28` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_28`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_29`
--

DROP TABLE IF EXISTS `qa_6_29`;
CREATE TABLE IF NOT EXISTS `qa_6_29` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_29`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_30`
--

DROP TABLE IF EXISTS `qa_6_30`;
CREATE TABLE IF NOT EXISTS `qa_6_30` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_30`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_31`
--

DROP TABLE IF EXISTS `qa_6_31`;
CREATE TABLE IF NOT EXISTS `qa_6_31` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_31`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_32`
--

DROP TABLE IF EXISTS `qa_6_32`;
CREATE TABLE IF NOT EXISTS `qa_6_32` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_32`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_33`
--

DROP TABLE IF EXISTS `qa_6_33`;
CREATE TABLE IF NOT EXISTS `qa_6_33` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_33`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_34`
--

DROP TABLE IF EXISTS `qa_6_34`;
CREATE TABLE IF NOT EXISTS `qa_6_34` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_34`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_35`
--

DROP TABLE IF EXISTS `qa_6_35`;
CREATE TABLE IF NOT EXISTS `qa_6_35` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(50) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(50) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_35`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_36`
--

DROP TABLE IF EXISTS `qa_6_36`;
CREATE TABLE IF NOT EXISTS `qa_6_36` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_36`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_37`
--

DROP TABLE IF EXISTS `qa_6_37`;
CREATE TABLE IF NOT EXISTS `qa_6_37` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_37`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_38`
--

DROP TABLE IF EXISTS `qa_6_38`;
CREATE TABLE IF NOT EXISTS `qa_6_38` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_38`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_39`
--

DROP TABLE IF EXISTS `qa_6_39`;
CREATE TABLE IF NOT EXISTS `qa_6_39` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_v_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_39`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_40`
--

DROP TABLE IF EXISTS `qa_6_40`;
CREATE TABLE IF NOT EXISTS `qa_6_40` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_40`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_41`
--

DROP TABLE IF EXISTS `qa_6_41`;
CREATE TABLE IF NOT EXISTS `qa_6_41` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_41`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_42`
--

DROP TABLE IF EXISTS `qa_6_42`;
CREATE TABLE IF NOT EXISTS `qa_6_42` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_42`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_43`
--

DROP TABLE IF EXISTS `qa_6_43`;
CREATE TABLE IF NOT EXISTS `qa_6_43` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_43`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_44`
--

DROP TABLE IF EXISTS `qa_6_44`;
CREATE TABLE IF NOT EXISTS `qa_6_44` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_44`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_45`
--

DROP TABLE IF EXISTS `qa_6_45`;
CREATE TABLE IF NOT EXISTS `qa_6_45` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_45`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_46`
--

DROP TABLE IF EXISTS `qa_6_46`;
CREATE TABLE IF NOT EXISTS `qa_6_46` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2_v_1` varchar(1) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL,
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_46`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_47`
--

DROP TABLE IF EXISTS `qa_6_47`;
CREATE TABLE IF NOT EXISTS `qa_6_47` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(50) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(50) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_47`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_48`
--

DROP TABLE IF EXISTS `qa_6_48`;
CREATE TABLE IF NOT EXISTS `qa_6_48` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_48`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_49`
--

DROP TABLE IF EXISTS `qa_6_49`;
CREATE TABLE IF NOT EXISTS `qa_6_49` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_49`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_50`
--

DROP TABLE IF EXISTS `qa_6_50`;
CREATE TABLE IF NOT EXISTS `qa_6_50` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(50) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(50) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_50`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_51`
--

DROP TABLE IF EXISTS `qa_6_51`;
CREATE TABLE IF NOT EXISTS `qa_6_51` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `pie_1_mp` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_51`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_6_52`
--

DROP TABLE IF EXISTS `qa_6_52`;
CREATE TABLE IF NOT EXISTS `qa_6_52` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `pie_1` varchar(10) NOT NULL DEFAULT '',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `pie_2` varchar(10) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_6_52`
--


-- --------------------------------------------------------

--
-- Table structure for table `qa_age`
--

DROP TABLE IF EXISTS `qa_age`;
CREATE TABLE IF NOT EXISTS `qa_age` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of the user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(10) NOT NULL DEFAULT '' COMMENT 'Age of user when couple met',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(10) NOT NULL DEFAULT '' COMMENT 'age of user when dating relationship ended',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(10) NOT NULL DEFAULT '' COMMENT 'age of partner when couple met',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(10) NOT NULL DEFAULT '' COMMENT 'age of partner when dating relationship ended',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_qa_age_user` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners ages' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `qa_age`
--

INSERT INTO `qa_age` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`, `q_3`, `q_3_pl`, `q_3_status`, `q_4`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '6', 2, 1, '6', 2, 1, '5', 2, 1, '5', 1, 1),
(2, 2, 2, '3', 3, 1, '3', 3, 1, '4', 2, 1, '4', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_gender`
--

DROP TABLE IF EXISTS `qa_gender`;
CREATE TABLE IF NOT EXISTS `qa_gender` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '1 => past | 2 => present',
  `q_1` varchar(25) NOT NULL DEFAULT '' COMMENT 'user gender',
  `q_1_pl` smallint(6) NOT NULL DEFAULT '0' COMMENT 'partner gender',
  `q_1_status` int(1) NOT NULL DEFAULT '0',
  `q_2` varchar(25) NOT NULL DEFAULT '',
  `q_2_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_2_status` int(1) NOT NULL DEFAULT '0',
  `q_3` varchar(25) NOT NULL DEFAULT '',
  `q_3_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_3_status` int(1) NOT NULL DEFAULT '0',
  `q_4` varchar(25) NOT NULL DEFAULT '',
  `q_4_pl` smallint(6) NOT NULL DEFAULT '0',
  `q_4_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_qa_gender_user` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='stores answers for the user and partners gender' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qa_gender`
--

INSERT INTO `qa_gender` (`id`, `user_id`, `type`, `q_1`, `q_1_pl`, `q_1_status`, `q_2`, `q_2_pl`, `q_2_status`, `q_3`, `q_3_pl`, `q_3_status`, `q_4`, `q_4_pl`, `q_4_status`) VALUES
(1, 2, 1, '0,0,1,0', 3, 1, '0,0,1,0', 3, 1, '0,0,1,0', 3, 1, '0,0,1,0', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `qa_income`
--

DROP TABLE IF EXISTS `qa_income`;
CREATE TABLE IF NOT EXISTS `qa_income` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'id of user',
  `user_low_range` int(11) NOT NULL COMMENT 'low range of user''s income',
  `user_high_range` int(11) NOT NULL COMMENT 'high range of user''s income',
  `partner_low_range` int(11) NOT NULL COMMENT 'low range of partner''s income',
  `partner_high_range` int(11) NOT NULL COMMENT 'high range of partner''s income',
  PRIMARY KEY (`id`),
  KEY `fk_qa_income_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores answers for the users and partners income.' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qa_income`
--


-- --------------------------------------------------------

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(100) NOT NULL COMMENT 'name of the qa_ table for the specific question',
  `level` int(11) NOT NULL COMMENT 'The question level for this question',
  `question_order` int(11) NOT NULL COMMENT 'The order in which the question will be presented on the site',
  `heading` varchar(255) NOT NULL COMMENT 'The heading which will appear at the top of the page for this question',
  `q_type` varchar(50) NOT NULL DEFAULT '',
  `q_sub` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `number_UNIQUE` (`table_name`),
  UNIQUE KEY `level_order` (`level`,`question_order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Specifies the order in which the questions will appear on th' AUTO_INCREMENT=368 ;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `table_name`, `level`, `question_order`, `heading`, `q_type`, `q_sub`) VALUES
(1, 'qa_age', 1, 1, 'Age', 'Scroller', 4),
(2, 'qa_gender', 1, 2, 'Gender', 'Selection', 4),
(3, 'qa_1_3', 1, 3, 'Income Range', 'Selection', 4),
(4, 'qa_1_4', 1, 4, 'Question 4', 'Selection', 4),
(5, 'qa_1_5', 1, 5, 'Question 5', 'Selection', 4),
(6, 'qa_1_6', 1, 6, 'Question 6', 'Selection', 4),
(7, 'qa_1_7', 1, 7, 'Question 7', 'Selection', 4),
(8, 'qa_1_8', 1, 8, 'Question 8', 'Range', 4),
(9, 'qa_1_9', 1, 9, 'Question 9', 'Range', 4),
(10, 'qa_1_10', 1, 10, 'Question 10', 'Range', 4),
(11, 'qa_1_11', 1, 11, 'Question 11', 'YesNo', 4),
(12, 'qa_1_12', 1, 12, 'Question 12', 'MultiSelection', 4),
(13, 'qa_1_13', 1, 13, 'Question 13', 'Selection', 2),
(14, 'qa_1_14', 1, 14, 'Question 14', 'Spinner', 4),
(15, 'qa_1_15', 1, 15, 'Question 15', 'YesNo', 2),
(16, 'qa_1_16', 1, 16, 'Question 16', 'YesNo', 2),
(17, 'qa_1_17', 1, 17, 'Question 17', 'Spinner', 4),
(18, 'qa_1_18', 1, 18, 'Question 18', 'Spinner', 4),
(19, 'qa_1_19', 1, 19, 'Question 19', 'Spinner', 4),
(20, 'qa_1_20', 1, 20, 'Question 20', 'Spinner', 4),
(21, 'qa_1_21', 1, 21, 'Question 21', 'Scroller', 4),
(22, 'qa_1_22', 1, 22, 'Question 22', 'Scroller', 4),
(23, 'qa_1_23', 1, 23, 'Question 23', 'Scroller', 4),
(24, 'qa_1_24', 1, 24, 'Question 24', 'Scroller', 4),
(25, 'qa_1_25', 1, 25, 'Question 25', 'Selection', 4),
(26, 'qa_1_26', 1, 26, 'Question 26', 'Selection', 4),
(27, 'qa_1_27', 1, 27, 'Question 27', 'Spinner', 4),
(28, 'qa_1_28', 1, 28, 'Question 28', 'Spinner', 4),
(29, 'qa_1_29', 1, 29, 'Question 29', 'Spinner', 4),
(30, 'qa_1_30', 1, 30, 'Question 30', 'Spinner', 4),
(31, 'qa_1_31', 1, 31, 'Question 31', 'Spinner', 4),
(32, 'qa_1_32', 1, 32, 'Q 33', 'YesNo', 4),
(33, 'qa_1_33', 1, 33, 'Q 34', 'YesNo', 4),
(34, 'qa_1_34', 1, 34, 'Q 34', 'DragDrop', 4),
(35, 'qa_1_35', 1, 35, 'Q 35', 'Selection', 1),
(36, 'qa_1_36', 1, 36, 'Q 36', 'YesNo_Selection', 1),
(37, 'qa_1_37', 1, 37, 'Q 37', 'YesNo_Selection', 1),
(38, 'qa_1_38', 1, 38, 'Q 38', 'YesNo', 1),
(39, 'qa_1_39', 1, 39, 'Q 39', 'Spinner', 2),
(40, 'qa_1_40', 1, 40, 'Q 40', 'Scroller', 1),
(41, 'qa_1_41', 1, 41, 'Q 41', 'Selection', 2),
(42, 'qa_1_42', 1, 42, 'Q 42', 'Spinner', 2),
(43, 'qa_1_43', 1, 43, 'Q 43', 'Spinner', 2),
(44, 'qa_1_44', 1, 44, 'Q 44', 'Selection', 1),
(45, 'qa_1_45', 1, 45, 'Q 45', 'Scroller', 2),
(46, 'qa_1_46', 1, 46, 'Q 46', 'Spinner', 2),
(47, 'qa_1_47', 1, 47, 'Q 47', 'Spinner', 2),
(48, 'qa_1_48', 1, 48, 'Q 48', 'Spinner', 2),
(49, 'qa_1_49', 1, 49, 'Q 49', 'Spinner', 1),
(50, 'qa_1_50', 1, 50, 'Q 50', 'Spinner', 2),
(51, 'qa_1_51', 1, 51, 'Q 51', 'Pie', 2),
(52, 'qa_1_52', 1, 52, 'Q 52', 'Pie', 2),
(53, 'qa_1_53', 1, 53, 'Q 53', 'Selection', 1),
(54, 'qa_1_54', 1, 54, 'Q 54', 'YesNo', 1),
(55, 'qa_1_55', 1, 55, 'Q 55', 'YesNo', 1),
(56, 'qa_1_56', 1, 56, 'Q 56', 'Spinner', 1),
(57, 'qa_1_57', 1, 57, 'Q 57', 'Spinner', 1),
(58, 'qa_1_58', 1, 58, 'Q 58', 'YesNo', 2),
(59, 'qa_1_59', 1, 59, 'Q 59', 'YesNo', 2),
(60, 'qa_1_60', 1, 60, 'Q 60', 'Spinner', 1),
(61, 'qa_1_61', 1, 61, 'Q 61', 'Pie', 1),
(62, 'qa_1_62', 1, 62, 'Q 62', 'Pie', 2),
(63, 'qa_2_1', 2, 1, 'Q 1', 'Scroller', 2),
(64, 'qa_2_2', 2, 2, 'Q 2', 'Selection', 2),
(65, 'qa_2_3', 2, 3, 'Q 3', 'Selection', 2),
(66, 'qa_2_4', 2, 4, 'Q 4', 'Scroller', 2),
(67, 'qa_2_5', 2, 5, 'Q 5', 'Selection', 2),
(68, 'qa_2_6', 2, 6, 'Q 6', 'Spinner', 2),
(69, 'qa_2_7', 2, 7, 'Q 7', 'Pie', 2),
(70, 'qa_2_8', 2, 8, 'Q 8', 'Pie', 2),
(71, 'qa_2_9', 2, 9, 'Q 9', 'Pie', 2),
(72, 'qa_2_10', 2, 10, 'Q 10', 'Pie', 2),
(73, 'qa_2_11', 2, 11, 'Q 11', 'Pie', 2),
(74, 'qa_2_12', 2, 12, 'Q 12', 'Scroller', 2),
(75, 'qa_2_13', 2, 13, 'Q 13', 'Spinner', 2),
(76, 'qa_2_14', 2, 14, 'Q 14', 'Spinner', 2),
(77, 'qa_2_15', 2, 15, 'Q 15', 'Spinner', 2),
(78, 'qa_2_16', 2, 16, 'Q 16', 'Pie', 2),
(79, 'qa_2_17', 2, 17, 'Q 17', 'Pie', 2),
(80, 'qa_2_18', 2, 18, 'Q 18', 'Pie', 2),
(81, 'qa_2_19', 2, 19, 'Q 19', 'Pie', 2),
(82, 'qa_2_20', 2, 20, 'Q 20', 'Pie', 2),
(83, 'qa_2_21', 2, 21, 'Q 21', 'Pie', 2),
(84, 'qa_2_22', 2, 22, 'Q 22', 'Spinner', 2),
(85, 'qa_2_23', 2, 23, 'Q 23', 'Spinner', 2),
(86, 'qa_2_24', 2, 24, 'Q 24', 'Scroller', 2),
(87, 'qa_2_25', 2, 25, 'Q 25', 'Spinner', 2),
(88, 'qa_2_26', 2, 26, 'Q 26', 'Spinner', 2),
(89, 'qa_2_27', 2, 27, 'Q 27', 'Household', 2),
(90, 'qa_2_28', 2, 28, 'Q 28', 'Ethicity', 2),
(91, 'qa_2_29', 2, 29, 'Q 29', 'No_Selection', 2),
(92, 'qa_2_30', 2, 30, 'Q 30', 'No_Selection', 2),
(93, 'qa_2_31', 2, 31, 'Q 31', 'YesNo_Double', 2),
(94, 'qa_2_32', 2, 32, 'Q 32', 'YesNo_Double', 2),
(95, 'qa_2_33', 2, 33, 'Q 33', 'Spinner', 2),
(96, 'qa_2_34', 2, 34, 'Q 34', 'Spinner', 2),
(97, 'qa_2_35', 2, 35, 'Q 35', 'Selection', 2),
(98, 'qa_2_36', 2, 36, 'Q 36', 'Selection', 2),
(99, 'qa_2_37', 2, 37, 'Q 37', 'Scroller', 2),
(100, 'qa_2_38', 2, 38, 'Q 38', 'Scroller', 2),
(101, 'qa_2_39', 2, 39, 'Q 39', 'Spinner', 2),
(102, 'qa_2_40', 2, 40, 'Q 40', 'Spinner', 2),
(103, 'qa_2_41', 2, 41, 'Q 41', 'Spinner', 2),
(104, 'qa_2_42', 2, 42, 'Q 42', 'Spinner', 2),
(105, 'qa_2_43', 2, 43, 'Q 43', 'DragDrop', 2),
(106, 'qa_2_44', 2, 44, 'Q 44', 'DragDrop', 2),
(107, 'qa_2_45', 2, 45, 'Q 45', 'DragDrop', 2),
(108, 'qa_2_46', 2, 46, 'Q 46', 'DragDrop', 2),
(109, 'qa_2_47', 2, 47, 'Q 47', 'DragDrop', 2),
(110, 'qa_2_48', 2, 48, 'Q 48', 'DragDrop', 2),
(111, 'qa_2_49', 2, 49, 'Q 49', 'DragDrop', 2),
(112, 'qa_2_50', 2, 50, 'Q 50', 'DragDrop', 2),
(113, 'qa_2_51', 2, 51, 'Q 51', 'DragDrop', 2),
(114, 'qa_2_52', 2, 52, 'Q 52', 'DragDrop', 2),
(115, 'qa_2_53', 2, 53, 'Q 53', 'DragDrop', 2),
(116, 'qa_2_54', 2, 54, 'Q 54', 'DragDrop', 2),
(117, 'qa_2_55', 2, 55, 'Q 55', 'DragDrop', 2),
(118, 'qa_2_56', 2, 56, 'Q 56', 'DragDrop', 2),
(119, 'qa_2_57', 2, 57, 'Q 57', 'DragDrop', 2),
(120, 'qa_2_58', 2, 58, 'Q 58', 'DragDrop', 2),
(121, 'qa_2_59', 2, 59, 'Q 59', 'DragDrop', 2),
(122, 'qa_2_60', 2, 60, 'Q 60', 'DragDrop', 2),
(123, 'qa_2_61', 2, 61, 'Q 61', 'DragDrop', 2),
(124, 'qa_2_62', 2, 62, 'Q 62', 'DragDrop', 2),
(125, 'qa_2_63', 2, 63, 'Q 63', 'DragDrop', 2),
(126, 'qa_2_64', 2, 64, 'Q 64', 'DragDrop', 2),
(127, 'qa_2_65', 2, 65, 'Q 65', 'DragDrop', 2),
(128, 'qa_3_1', 3, 1, 'Q 1', 'TypeB', 2),
(129, 'qa_3_2', 3, 2, 'Q 2', 'TypeB', 2),
(130, 'qa_3_3', 3, 3, 'Q 3', 'TypeB', 2),
(131, 'qa_3_4', 3, 4, 'Q 4', 'TypeB', 2),
(132, 'qa_3_5', 3, 5, 'Q 5', 'TypeB', 2),
(133, 'qa_3_6', 3, 6, 'Q 6', 'TypeB', 2),
(134, 'qa_3_7', 3, 7, 'Q 7', 'TypeA', 2),
(135, 'qa_3_8', 3, 8, 'Q 8', 'TypeA', 2),
(136, 'qa_3_9', 3, 9, 'Q 9', 'TypeA', 2),
(137, 'qa_3_10', 3, 10, 'Q 10', 'TypeA', 2),
(138, 'qa_3_11', 3, 11, 'Q 11', 'TypeA', 2),
(139, 'qa_3_12', 3, 12, 'Q 12', 'TypeA', 2),
(140, 'qa_3_13', 3, 13, 'Q 13', 'TypeA', 2),
(141, 'qa_3_14', 3, 14, 'Q 14', 'TypeA', 2),
(142, 'qa_3_15', 3, 15, 'Q 15', 'TypeA', 2),
(143, 'qa_3_16', 3, 16, 'Q 16', 'TypeB', 2),
(144, 'qa_3_17', 3, 17, 'Q 17', 'TypeB', 2),
(145, 'qa_3_18', 3, 18, 'Q 18', 'TypeB', 2),
(146, 'qa_3_19', 3, 19, 'Q 19', 'TypeB', 2),
(147, 'qa_3_20', 3, 20, 'Q 20', 'TypeB', 2),
(148, 'qa_3_21', 3, 21, 'Q 21', 'TypeA', 2),
(149, 'qa_3_22', 3, 22, 'Q 22', 'TypeA', 2),
(150, 'qa_3_23', 3, 23, 'Q 23', 'TypeB', 2),
(151, 'qa_3_24', 3, 24, 'Q 24', 'TypeB', 2),
(152, 'qa_3_25', 3, 25, 'Q 25', 'TypeB', 2),
(153, 'qa_3_26', 3, 26, 'Q 26', 'TypeB', 2),
(154, 'qa_3_27', 3, 27, 'Q 27', 'TypeC', 2),
(155, 'qa_3_28', 3, 28, 'Q 28', 'TypeC', 2),
(156, 'qa_3_29', 3, 29, 'Q 29', 'TypeC', 2),
(157, 'qa_3_30', 3, 30, 'Q 30', 'TypeC', 2),
(158, 'qa_3_31', 3, 31, 'Q 31', 'TypeC', 2),
(159, 'qa_3_32', 3, 32, 'Q 32', 'TypeC', 2),
(160, 'qa_3_33', 3, 33, 'Q 33', 'TypeC', 2),
(161, 'qa_3_34', 3, 34, 'Q 34', 'TypeC', 2),
(162, 'qa_3_35', 3, 35, 'Q 35', 'TypeC', 2),
(163, 'qa_3_36', 3, 36, 'Q 36', 'TypeA', 2),
(164, 'qa_3_37', 3, 37, 'Q 37', 'TypeA', 2),
(165, 'qa_3_38', 3, 38, 'Q 38', 'TypeA', 2),
(166, 'qa_3_39', 3, 39, 'Q 39', 'TypeA', 2),
(167, 'qa_3_40', 3, 40, 'Q 40', 'TypeA', 2),
(168, 'qa_3_41', 3, 41, 'Q 41', 'TypeB', 2),
(169, 'qa_3_42', 3, 42, 'Q 42', 'TypeB', 2),
(170, 'qa_3_43', 3, 43, 'Q 43', 'TypeC', 2),
(171, 'qa_3_44', 3, 44, 'Q 44', 'TypeC', 2),
(172, 'qa_3_45', 3, 45, 'Q 45', 'TypeC', 2),
(173, 'qa_3_46', 3, 46, 'Q 46', 'TypeC', 2),
(174, 'qa_3_47', 3, 47, 'Q 47', 'TypeC', 2),
(175, 'qa_3_48', 3, 48, 'Q 48', 'TypeC', 2),
(176, 'qa_3_49', 3, 49, 'Q 49', 'TypeC', 2),
(177, 'qa_3_50', 3, 50, 'Q 50', 'TypeC', 2),
(178, 'qa_3_51', 3, 51, 'Q 51', 'TypeC', 2),
(179, 'qa_3_52', 3, 52, 'Q 52', 'TypeC', 2),
(180, 'qa_3_53', 3, 53, 'Q 53', 'TypeC', 2),
(181, 'qa_3_54', 3, 54, 'Q 54', 'TypeC', 2),
(182, 'qa_3_55', 3, 55, 'Q 55', 'TypeC', 2),
(183, 'qa_3_56', 3, 56, 'Q 56', 'TypeC', 2),
(184, 'qa_3_57', 3, 57, 'Q 57', 'TypeC', 2),
(185, 'qa_3_58', 3, 58, 'Q 58', 'TypeC', 2),
(186, 'qa_3_59', 3, 59, 'Q 59', 'TypeC', 2),
(187, 'qa_3_60', 3, 60, 'Q 60', 'TypeC', 2),
(188, 'qa_3_61', 3, 61, 'Q 61', 'TypeC', 2),
(189, 'qa_3_62', 3, 62, 'Q 62', 'TypeC', 2),
(190, 'qa_3_63', 3, 63, 'Q 63', 'TypeC', 2),
(191, 'qa_3_64', 3, 64, 'Q 64', 'TypeC', 2),
(192, 'qa_3_65', 3, 65, 'Q 65', 'TypeC', 2),
(193, 'qa_4_1', 4, 1, 'Q 1', 'Selection', 2),
(194, 'qa_4_2', 4, 2, 'Q 2', 'Selection', 1),
(195, 'qa_4_3', 4, 3, 'Q 3', 'Pie', 1),
(196, 'qa_4_4', 4, 4, 'Q 4', 'Selection', 2),
(197, 'qa_4_5', 4, 5, 'Q 5', 'Selection', 2),
(198, 'qa_4_6', 4, 6, 'Q 6', 'Selection', 2),
(199, 'qa_4_7', 4, 7, 'Q 7', 'Spiner', 2),
(200, 'qa_4_8', 4, 8, 'Q 8', 'Pie', 2),
(201, 'qa_4_9', 4, 9, 'Q 9', 'Pie', 2),
(202, 'qa_4_10', 4, 10, 'Q 10', 'Pie', 2),
(203, 'qa_4_11', 4, 11, 'Q 11', 'Pie', 2),
(204, 'qa_4_12', 4, 12, 'Q 12', 'Spinner', 1),
(205, 'qa_4_13', 4, 13, 'Q 13', 'Spinner', 1),
(206, 'qa_4_14', 4, 14, 'Q 14', 'YesNo', 2),
(207, 'qa_4_15', 4, 15, 'Q 15', 'Selection', 1),
(208, 'qa_4_16', 4, 16, 'Q 16', 'Selection', 1),
(209, 'qa_4_17', 4, 17, 'Q 17', 'Spiner', 1),
(210, 'qa_4_18', 4, 18, 'Q 18', 'Spinner', 2),
(211, 'qa_4_19', 4, 19, 'Q 19', 'Selection', 1),
(212, 'qa_4_20', 4, 20, 'Q 20', 'Selection', 1),
(213, 'qa_4_21', 4, 21, 'Q 21', 'Spinner', 1),
(214, 'qa_4_22', 4, 22, 'Q 22', 'Spinner', 1),
(215, 'qa_4_23', 4, 23, 'Q 23', 'Selection', 1),
(216, 'qa_4_24', 4, 24, 'Q 24', 'Selection', 2),
(217, 'qa_4_25', 4, 25, 'Q 25', 'Selection', 1),
(218, 'qa_4_26', 4, 26, 'Q 26', 'Spinner', 2),
(219, 'qa_4_27', 4, 27, 'Q 27', 'Scroller', 2),
(220, 'qa_4_28', 4, 28, 'Q 28', 'Scroller', 2),
(221, 'qa_4_29', 4, 29, 'Q 29', 'YesNo', 2),
(222, 'qa_4_30', 4, 30, 'Q 30', 'Selection', 2),
(223, 'qa_4_31', 4, 31, 'Q 31', 'Scroller', 2),
(224, 'qa_4_32', 4, 32, 'Q 32', 'Scroller', 2),
(225, 'qa_4_33', 4, 33, 'Q 33', 'YesNo', 2),
(226, 'qa_4_34', 4, 34, 'Q 34', 'Spinner', 1),
(227, 'qa_4_35', 4, 35, 'Q 35', 'Spinner', 2),
(228, 'qa_4_36', 4, 36, 'Q 36', 'Spinner', 2),
(229, 'qa_4_37', 4, 37, 'Q 37', 'Spinner', 1),
(230, 'qa_4_38', 4, 38, 'Q 38', 'Spinner', 2),
(231, 'qa_4_39', 4, 39, 'Q 39', 'Spinner', 2),
(232, 'qa_4_40', 4, 40, 'Q 40', 'Spinner', 2),
(233, 'qa_4_41', 4, 41, 'Q 41', 'Selection', 2),
(234, 'qa_4_42', 4, 42, 'Q 42', 'Selection', 2),
(235, 'qa_4_43', 4, 43, 'Q 43', 'YesNo', 2),
(236, 'qa_4_44', 4, 44, 'Q 44', 'Pie', 2),
(237, 'qa_4_45', 4, 45, 'Q 45', 'YesNo', 2),
(238, 'qa_4_46', 4, 46, 'Q 46', 'Spinner', 2),
(239, 'qa_4_47', 4, 47, 'Q 47', 'Spinner', 2),
(240, 'qa_4_48', 4, 48, 'Q 48', 'Spinner', 2),
(241, 'qa_4_49', 4, 49, 'Q 49', 'Selection', 1),
(242, 'qa_4_50', 4, 50, 'Q 50', 'Spinner', 2),
(243, 'qa_4_51', 4, 51, 'Q 51', 'Spinner', 2),
(244, 'qa_4_52', 4, 52, 'Q 52', 'Selection', 2),
(245, 'qa_4_53', 4, 53, 'Q 53', 'Selection', 1),
(246, 'qa_4_54', 4, 54, 'Q 54', 'Selection', 2),
(247, 'qa_4_55', 4, 55, 'Q 55', 'Selection', 1),
(248, 'qa_4_56', 4, 56, 'Q 56', 'Selection', 2),
(249, 'qa_4_57', 4, 57, 'Q 57', 'Selection', 1),
(250, 'qa_4_58', 4, 58, 'Q 58', 'Selection', 2),
(251, 'qa_4_59', 4, 59, 'Q 59', 'Selection', 1),
(252, 'qa_4_60', 4, 60, 'Q 60', 'Selection', 2),
(253, 'qa_4_61', 4, 61, 'Q 61', 'Selection', 1),
(254, 'qa_4_62', 4, 62, 'Q 62', 'Selection', 2),
(255, 'qa_4_63', 4, 63, 'Q 63', 'Selection', 1),
(256, 'qa_5_1', 5, 1, 'Q 1', 'YesNo', 1),
(257, 'qa_5_2', 5, 2, 'Q 2', 'YesNoDouble', 2),
(258, 'qa_5_3', 5, 3, 'Q 3', 'Spinner', 2),
(259, 'qa_5_4', 5, 4, 'Q 4', 'Spinner', 1),
(260, 'qa_5_5', 5, 5, 'Q 5', 'Selection', 1),
(261, 'qa_5_6', 5, 6, 'Q 6', 'Scroller', 1),
(262, 'qa_5_7', 5, 7, 'Q 7', 'Pie', 1),
(263, 'qa_5_8', 5, 8, 'Q 8', 'Pie', 1),
(264, 'qa_5_9', 5, 9, 'Q 9', 'Selection', 1),
(265, 'qa_5_10', 5, 10, 'Q 10', 'Pie', 1),
(266, 'qa_5_11', 5, 11, 'Q 11', 'Pie', 2),
(267, 'qa_5_12', 5, 12, 'Q 12', 'Selection', 1),
(268, 'qa_5_13', 5, 13, 'Q 13', 'Scroller', 1),
(269, 'qa_5_14', 5, 14, 'Q 14', 'Pie', 1),
(270, 'qa_5_15', 5, 15, 'Q 15', 'Pie', 1),
(271, 'qa_5_16', 5, 16, 'Q 16', 'Selection', 1),
(272, 'qa_5_17', 5, 17, 'Q 17', 'Pie', 1),
(273, 'qa_5_18', 5, 18, 'Q 18', 'Pie', 2),
(274, 'qa_5_19', 5, 19, 'Q 19', 'Selection', 1),
(275, 'qa_5_20', 5, 20, 'Q 20', 'Scroller', 1),
(276, 'qa_5_21', 5, 21, 'Q 21', 'Pie', 1),
(277, 'qa_5_22', 5, 22, 'Q 22', 'Pie', 1),
(278, 'qa_5_23', 5, 23, 'Q 23', 'Selection', 1),
(279, 'qa_5_24', 5, 24, 'Q 24', 'Pie', 1),
(280, 'qa_5_25', 5, 25, 'Q 25', 'Pie', 2),
(281, 'qa_5_26', 5, 26, 'Q 26', 'Selection', 1),
(282, 'qa_5_27', 5, 27, 'Q 27', 'Scroller', 1),
(283, 'qa_5_28', 5, 28, 'Q 28', 'Pie', 1),
(284, 'qa_5_29', 5, 29, 'Q 29', 'Pie', 1),
(285, 'qa_5_30', 5, 30, 'Q 30', 'Selection', 1),
(286, 'qa_5_31', 5, 31, 'Q 31', 'Pie', 1),
(287, 'qa_5_32', 5, 32, 'Q 32', 'Pie', 2),
(288, 'qa_5_33', 5, 33, 'Q 33', 'Selection', 1),
(289, 'qa_5_34', 5, 34, 'Q 34', 'Scroller', 1),
(290, 'qa_5_35', 5, 35, 'Q 35', 'Pie', 1),
(291, 'qa_5_36', 5, 36, 'Q 36', 'Pie', 1),
(292, 'qa_5_37', 5, 37, 'Q 37', 'Selection', 1),
(293, 'qa_5_38', 5, 38, 'Q 38', 'Pie', 1),
(294, 'qa_5_39', 5, 39, 'Q 39', 'Pie', 2),
(295, 'qa_5_40', 5, 40, 'Q 40', 'Selection', 1),
(296, 'qa_5_41', 5, 41, 'Q 41', 'Scroller', 1),
(297, 'qa_5_42', 5, 42, 'Q 42', 'Pie', 1),
(298, 'qa_5_43', 5, 43, 'Q 43', 'Pie', 1),
(299, 'qa_5_44', 5, 44, 'Q 44', 'Selection', 1),
(300, 'qa_5_45', 5, 45, 'Q 45', 'Pie', 1),
(301, 'qa_5_46', 5, 46, 'Q 46', 'Pie', 2),
(302, 'qa_5_47', 5, 47, 'Q 47', 'Selection', 1),
(303, 'qa_5_48', 5, 48, 'Q 48', 'Scroller', 1),
(304, 'qa_5_49', 5, 49, 'Q 49', 'Pie', 1),
(305, 'qa_5_50', 5, 50, 'Q 50', 'Pie', 1),
(306, 'qa_5_51', 5, 51, 'Q 51', 'Selection', 1),
(307, 'qa_5_52', 5, 52, 'Q 52', 'Pie', 1),
(308, 'qa_5_53', 5, 53, 'Q 53', 'Pie', 2),
(309, 'qa_5_54', 5, 54, 'Q 54', 'Spinner', 2),
(310, 'qa_5_55', 5, 55, 'Q 55', 'YesNo', 2),
(311, 'qa_5_56', 5, 56, 'Q 56', 'Spinner', 2),
(312, 'qa_5_57', 5, 57, 'Q 57', 'Selection', 2),
(313, 'qa_5_58', 5, 58, 'Q 58', 'Spinner', 2),
(314, 'qa_5_59', 5, 59, 'Q 59', 'Selection', 2),
(315, 'qa_5_60', 5, 60, 'Q 60', 'Selection', 2),
(316, 'qa_6_1', 6, 1, 'Q 1', 'Spinner', 2),
(317, 'qa_6_2', 6, 2, 'Q 2', 'Spinner', 2),
(318, 'qa_6_3', 6, 3, 'Q 3', 'Spinner', 2),
(319, 'qa_6_4', 6, 4, 'Q 4', 'Spinner', 2),
(320, 'qa_6_5', 6, 5, 'Q 5', 'Spinner', 2),
(321, 'qa_6_6', 6, 6, 'Q 6', 'Spinner', 2),
(322, 'qa_6_7', 6, 7, 'Q 7', 'Spinner', 2),
(323, 'qa_6_8', 6, 8, 'Q 8', 'Spinner', 2),
(324, 'qa_6_9', 6, 9, 'Q 9', 'Spinner', 2),
(325, 'qa_6_10', 6, 10, 'Q 10', 'YesNo', 2),
(326, 'qa_6_11', 6, 11, 'Q 11', 'Selection', 2),
(327, 'qa_6_12', 6, 12, 'Q 12', 'Selection', 2),
(328, 'qa_6_13', 6, 13, 'Q 13', 'Selection', 2),
(329, 'qa_6_14', 6, 14, 'Q 14', 'Selection', 2),
(330, 'qa_6_15', 6, 15, 'Q 15', 'Pie', 2),
(331, 'qa_6_16', 6, 16, 'Q 16', 'Scroller', 2),
(332, 'qa_6_17', 6, 17, 'Q 17', 'Scroller', 2),
(333, 'qa_6_18', 6, 18, 'Q 18', 'Scroller', 2),
(334, 'qa_6_19', 6, 19, 'Q 19', 'Scroller', 2),
(335, 'qa_6_20', 6, 20, 'Q 20', 'Scroller', 1),
(336, 'qa_6_21', 6, 21, 'Q 21', 'Pie', 2),
(337, 'qa_6_22', 6, 22, 'Q 22', 'Pie', 2),
(338, 'qa_6_23', 6, 23, 'Q 23', 'Spinner', 2),
(339, 'qa_6_24', 6, 24, 'Q 24', 'YesNo', 2),
(340, 'qa_6_25', 6, 25, 'Q 25', 'Spinner', 2),
(341, 'qa_6_26', 6, 26, 'Q 26', 'Selection', 2),
(342, 'qa_6_27', 6, 27, 'Q 27', 'Selection', 2),
(343, 'qa_6_28', 6, 28, 'Q 28', 'Spinner', 2),
(344, 'qa_6_29', 6, 29, 'Q 29', 'Spinner', 2),
(345, 'qa_6_30', 6, 30, 'Q 30', 'Spinner', 2),
(346, 'qa_6_31', 6, 31, 'Q 31', 'Selection', 2),
(347, 'qa_6_32', 6, 32, 'Q 32', 'Selection', 2),
(348, 'qa_6_33', 6, 33, 'Q 33', 'Spinner', 2),
(349, 'qa_6_34', 6, 34, 'Q 34', 'Spinner', 2),
(350, 'qa_6_35', 6, 35, 'Q 35', 'Scroller', 2),
(351, 'qa_6_36', 6, 36, 'Q 36', 'Pie', 1),
(352, 'qa_6_37', 6, 37, 'Q 37', 'Pie', 2),
(353, 'qa_6_38', 6, 38, 'Q 38', 'Spinner', 2),
(354, 'qa_6_39', 6, 39, 'Q 39', 'Spinner', 2),
(355, 'qa_6_40', 6, 40, 'Q 40', 'Spinner', 2),
(356, 'qa_6_41', 6, 41, 'Q 41', 'Spinner', 2),
(357, 'qa_6_42', 6, 42, 'Q 42', 'Spinner', 2),
(358, 'qa_6_43', 6, 43, 'Q 43', 'Spinner', 2),
(359, 'qa_6_44', 6, 44, 'Q 44', 'Spinner', 2),
(360, 'qa_6_45', 6, 45, 'Q 45', 'Spinner', 2),
(361, 'qa_6_46', 6, 46, 'Q 46', 'Spinner', 2),
(362, 'qa_6_47', 6, 47, 'Q 47', 'Scroller', 2),
(363, 'qa_6_48', 6, 48, 'Q 48', 'Pie', 1),
(364, 'qa_6_49', 6, 49, 'Q 49', 'Pie', 2),
(365, 'qa_6_50', 6, 50, 'Q 50', 'Scroller', 2),
(366, 'qa_6_51', 6, 51, 'Q 51', 'Pie', 1),
(367, 'qa_6_52', 6, 52, 'Q 52', 'Pie', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL COMMENT 'username.  this will be unique, so users will need to specify a username which isn''t taken',
  `email` varchar(200) DEFAULT NULL COMMENT 'email of the user',
  `password` varchar(200) DEFAULT NULL COMMENT 'password.  We should think about using some kind of secure salt method when storing the encrypted password',
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `hybrid_auth_provider_name` varchar(255) DEFAULT NULL,
  `hybrid_auth_provider_uid` varchar(255) DEFAULT NULL,
  `level_1` double(6,2) NOT NULL DEFAULT '0.00',
  `level_2` double(6,2) NOT NULL DEFAULT '0.00',
  `level_3` double(6,2) NOT NULL DEFAULT '0.00',
  `level_4` double(6,2) NOT NULL DEFAULT '0.00',
  `level_5` double(6,2) NOT NULL DEFAULT '0.00',
  `level_6` double(6,2) NOT NULL DEFAULT '0.00',
  `level_7` double(6,2) NOT NULL DEFAULT '0.00',
  `present_level_1` double(6,2) NOT NULL DEFAULT '0.00',
  `present_level_2` double(6,2) NOT NULL DEFAULT '0.00',
  `present_level_3` double(6,2) NOT NULL DEFAULT '0.00',
  `present_level_4` double(6,2) NOT NULL DEFAULT '0.00',
  `present_level_5` double(6,2) NOT NULL DEFAULT '0.00',
  `present_level_6` double(6,2) NOT NULL DEFAULT '0.00',
  `dailymood_hide` int(1) NOT NULL DEFAULT '0',
  `dailymood` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'The timestamp when the record was created',
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'timestamp of when the user last logged in',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This will hold data for each user, and will be used for logi' AUTO_INCREMENT=12 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `first_name`, `last_name`, `hybrid_auth_provider_name`, `hybrid_auth_provider_uid`, `level_1`, `level_2`, `level_3`, `level_4`, `level_5`, `level_6`, `level_7`, `present_level_1`, `present_level_2`, `present_level_3`, `present_level_4`, `present_level_5`, `present_level_6`, `dailymood_hide`, `dailymood`, `created`, `last_login`) VALUES
(1, 'andonis', 'antonis.mytidis@gmail.com', 'password', 'Andonis', 'Mytidis', NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, '2014-11-08 16:47:55', '0000-00-00 00:00:00'),
(2, 'muhammad', 'qaisar.qammar@gmail.com', '123456', 'Muhammad', 'Qaisar', NULL, NULL, 6.96, 10.01, 3.08, 1.94, 3.96, 0.00, 0.00, 2.32, 0.00, 3.08, 0.00, 0.00, 0.00, 0, 151, '2015-03-31 12:06:45', '2015-03-31 12:06:45'),
(3, 'mitcheljh', 'mjhaas@datasoftsolutions.net', 'password', 'Mitchell', 'Haas', NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, '2014-11-08 16:48:07', '0000-00-00 00:00:00'),
(4, NULL, 'qaisar_qammar@hotmail.com', '123456', NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, '2015-03-09 05:12:10', '2015-01-31 03:06:41'),
(5, NULL, 'aaa@gmail.com', '0000', NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, '2015-01-30 01:29:54', '0000-00-00 00:00:00'),
(10, NULL, 'qaisar.qammar1@gmail.com', '000000', NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, '2015-01-30 04:59:13', '0000-00-00 00:00:00'),
(11, NULL, 'qaisarkashif@gmail.com', '123456', NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, '2015-01-31 14:43:57', '0000-00-00 00:00:00');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `qa_age`
--
ALTER TABLE `qa_age`
  ADD CONSTRAINT `fk_qa_age_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `qa_gender`
--
ALTER TABLE `qa_gender`
  ADD CONSTRAINT `fk_qa_gender_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `qa_income`
--
ALTER TABLE `qa_income`
  ADD CONSTRAINT `fk_qa_income_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
